/********************************************************************************
** Form generated from reading UI file 'radio3.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RADIO3_H
#define UI_RADIO3_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Radio3
{
public:
    QPlainTextEdit *plainTextEdit;
    QPushButton *pushButton;
    QFrame *frame;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QFrame *frame_2;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_6;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QLabel *label;
    QLabel *label_2;
    QFrame *frame_3;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_8;
    QRadioButton *radioButton_3;

    void setupUi(QWidget *Radio3)
    {
        if (Radio3->objectName().isEmpty())
            Radio3->setObjectName(QString::fromUtf8("Radio3"));
        Radio3->resize(830, 496);
        Radio3->setMinimumSize(QSize(830, 496));
        Radio3->setMaximumSize(QSize(830, 496));
        Radio3->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        plainTextEdit = new QPlainTextEdit(Radio3);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        plainTextEdit->setGeometry(QRect(210, 240, 411, 211));
        plainTextEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        plainTextEdit->setReadOnly(true);
        pushButton = new QPushButton(Radio3);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(380, 450, 81, 31));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        frame = new QFrame(Radio3);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(20, 290, 191, 121));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        lineEdit = new QLineEdit(frame);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(40, 50, 113, 20));
        lineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_2 = new QLineEdit(frame);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(40, 90, 113, 20));
        lineEdit_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_3 = new QLineEdit(frame);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(40, 10, 41, 20));
        lineEdit_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_4 = new QLineEdit(frame);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(110, 10, 41, 20));
        lineEdit_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        frame_2 = new QFrame(Radio3);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setGeometry(QRect(630, 290, 181, 121));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        lineEdit_5 = new QLineEdit(frame_2);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(40, 30, 113, 20));
        lineEdit_5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_6 = new QLineEdit(frame_2);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(40, 70, 113, 20));
        lineEdit_6->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        radioButton = new QRadioButton(Radio3);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(70, 270, 111, 17));
        radioButton->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        radioButton_2 = new QRadioButton(Radio3);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(670, 270, 101, 17));
        radioButton_2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        label = new QLabel(Radio3);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(200, 0, 411, 61));
        label_2 = new QLabel(Radio3);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(200, 60, 411, 31));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        frame_3 = new QFrame(Radio3);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(320, 110, 181, 121));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        lineEdit_7 = new QLineEdit(frame_3);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(60, 30, 61, 20));
        lineEdit_7->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_7->setMaxLength(4);
        lineEdit_8 = new QLineEdit(frame_3);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(60, 70, 61, 20));
        lineEdit_8->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_8->setMaxLength(2);
        radioButton_3 = new QRadioButton(Radio3);
        radioButton_3->setObjectName(QString::fromUtf8("radioButton_3"));
        radioButton_3->setGeometry(QRect(360, 90, 101, 17));
        radioButton_3->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        retranslateUi(Radio3);

        QMetaObject::connectSlotsByName(Radio3);
    } // setupUi

    void retranslateUi(QWidget *Radio3)
    {
        Radio3->setWindowTitle(QCoreApplication::translate("Radio3", "Form", nullptr));
        pushButton->setText(QCoreApplication::translate("Radio3", "\331\206\331\205\330\247\333\214\330\264 \330\247\330\267\331\204\330\247\330\271\330\247\330\252", nullptr));
        lineEdit->setPlaceholderText(QCoreApplication::translate("Radio3", "\331\206\330\247\331\205 \330\247\330\252\331\210\331\205\330\250\333\214\331\204 \331\205\331\210\330\261\330\257 \331\206\330\270\330\261...", nullptr));
        lineEdit_2->setPlaceholderText(QCoreApplication::translate("Radio3", "\330\261\331\206\332\257 \330\247\330\252\331\210\331\205\330\250\333\214\331\204 \331\205\331\210\330\261\330\257 \331\206\330\270\330\261...", nullptr));
        lineEdit_3->setPlaceholderText(QCoreApplication::translate("Radio3", "\330\247\330\262 \330\263\330\247\331\204", nullptr));
        lineEdit_4->setPlaceholderText(QCoreApplication::translate("Radio3", "\330\252\330\247 \330\263\330\247\331\204", nullptr));
        lineEdit_5->setPlaceholderText(QCoreApplication::translate("Radio3", "\331\206\330\247\331\205 \330\264\330\256\330\265 \331\205\331\210\330\261\330\257 \331\206\330\270\330\261...", nullptr));
        lineEdit_6->setPlaceholderText(QCoreApplication::translate("Radio3", "\331\201\330\247\331\205\333\214\331\204 \330\264\330\256\330\265 \331\205\331\210\330\261\330\257 \331\206\330\270\330\261", nullptr));
        radioButton->setText(QCoreApplication::translate("Radio3", "\330\247\330\252\331\210\331\205\330\250\333\214\331\204 \331\205\331\210\330\261\330\257 \331\206\330\270\330\261", nullptr));
        radioButton_2->setText(QCoreApplication::translate("Radio3", "\330\264\330\256\330\265 \331\205\331\210\330\261\330\257 \331\206\330\270\330\261", nullptr));
        label->setText(QCoreApplication::translate("Radio3", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600;\">\330\254\330\263\330\252 \331\210 \330\254\331\210\333\214 \330\247\330\252\331\210\331\205\330\250\333\214\331\204\333\214 \333\214\330\247 \330\247\331\206\330\263\330\247\331\206 \331\205\331\210\330\261\330\257 \331\206\330\270\330\261 \330\264\331\205\330\247</span></p></body></html>", nullptr));
        label_2->setText(QCoreApplication::translate("Radio3", "<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:600;\">\331\204\330\267\331\201\330\247 \330\247\330\267\331\204\330\247\330\271\330\247\330\252 \330\247\330\252\331\210\331\205\330\250\333\214\331\204 \333\214\330\247 \330\247\331\206\330\263\330\247\331\206 \330\261\330\247 \330\250\331\207 \330\265\331\210\330\261\330\252 \332\251\330\247\331\205\331\204 \331\276\330\261 \332\251\331\206\333\214\330\257</span></p></body></html>", nullptr));
        lineEdit_7->setText(QString());
        lineEdit_7->setPlaceholderText(QCoreApplication::translate("Radio3", "\330\263\330\247\331\204...", nullptr));
        lineEdit_8->setText(QString());
        lineEdit_8->setPlaceholderText(QCoreApplication::translate("Radio3", "\331\205\330\247\331\207...", nullptr));
        radioButton_3->setText(QCoreApplication::translate("Radio3", "\331\202\331\210\331\204\331\206\330\247\331\205\331\207 \331\205\331\210\330\261\330\257 \331\206\330\270\330\261", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Radio3: public Ui_Radio3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RADIO3_H
