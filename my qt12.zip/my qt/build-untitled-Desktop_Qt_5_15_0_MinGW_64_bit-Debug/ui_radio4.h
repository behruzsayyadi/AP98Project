/********************************************************************************
** Form generated from reading UI file 'radio4.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RADIO4_H
#define UI_RADIO4_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Radio4
{
public:
    QLabel *label_3;
    QLineEdit *lineEdit_23;
    QLineEdit *lineEdit_34;
    QLineEdit *lineEdit_33;
    QLineEdit *lineEdit_22;
    QLineEdit *lineEdit_10;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_13;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_12;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_36;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_20;
    QLabel *label_2;
    QLineEdit *lineEdit_21;
    QLabel *label_4;
    QLineEdit *lineEdit_8;
    QLineEdit *lineEdit_40;
    QLineEdit *lineEdit_17;
    QLineEdit *lineEdit_30;
    QLineEdit *lineEdit_19;
    QLineEdit *lineEdit_32;
    QLineEdit *lineEdit_27;
    QLabel *label;
    QLineEdit *lineEdit_37;
    QLineEdit *lineEdit_16;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_24;
    QLineEdit *lineEdit_26;
    QLineEdit *lineEdit_35;
    QLineEdit *lineEdit_28;
    QPushButton *pushButton;
    QLineEdit *lineEdit_14;
    QLineEdit *lineEdit_9;
    QLineEdit *lineEdit_31;
    QLineEdit *lineEdit_29;
    QLineEdit *lineEdit_18;
    QLineEdit *lineEdit_15;
    QLineEdit *lineEdit_11;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit_39;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_25;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_38;

    void setupUi(QWidget *Radio4)
    {
        if (Radio4->objectName().isEmpty())
            Radio4->setObjectName(QString::fromUtf8("Radio4"));
        Radio4->resize(706, 453);
        label_3 = new QLabel(Radio4);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(260, 30, 61, 16));
        lineEdit_23 = new QLineEdit(Radio4);
        lineEdit_23->setObjectName(QString::fromUtf8("lineEdit_23"));
        lineEdit_23->setGeometry(QRect(360, 200, 113, 20));
        lineEdit_34 = new QLineEdit(Radio4);
        lineEdit_34->setObjectName(QString::fromUtf8("lineEdit_34"));
        lineEdit_34->setGeometry(QRect(230, 290, 113, 20));
        lineEdit_33 = new QLineEdit(Radio4);
        lineEdit_33->setObjectName(QString::fromUtf8("lineEdit_33"));
        lineEdit_33->setGeometry(QRect(100, 290, 113, 20));
        lineEdit_22 = new QLineEdit(Radio4);
        lineEdit_22->setObjectName(QString::fromUtf8("lineEdit_22"));
        lineEdit_22->setGeometry(QRect(230, 200, 113, 20));
        lineEdit_10 = new QLineEdit(Radio4);
        lineEdit_10->setObjectName(QString::fromUtf8("lineEdit_10"));
        lineEdit_10->setGeometry(QRect(230, 110, 113, 20));
        lineEdit_3 = new QLineEdit(Radio4);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(360, 50, 113, 20));
        lineEdit_13 = new QLineEdit(Radio4);
        lineEdit_13->setObjectName(QString::fromUtf8("lineEdit_13"));
        lineEdit_13->setGeometry(QRect(100, 140, 113, 20));
        lineEdit_4 = new QLineEdit(Radio4);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(490, 50, 113, 20));
        lineEdit_12 = new QLineEdit(Radio4);
        lineEdit_12->setObjectName(QString::fromUtf8("lineEdit_12"));
        lineEdit_12->setGeometry(QRect(490, 110, 113, 20));
        lineEdit_2 = new QLineEdit(Radio4);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(230, 50, 113, 20));
        lineEdit_36 = new QLineEdit(Radio4);
        lineEdit_36->setObjectName(QString::fromUtf8("lineEdit_36"));
        lineEdit_36->setGeometry(QRect(490, 290, 113, 20));
        lineEdit_6 = new QLineEdit(Radio4);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(230, 80, 113, 20));
        lineEdit_20 = new QLineEdit(Radio4);
        lineEdit_20->setObjectName(QString::fromUtf8("lineEdit_20"));
        lineEdit_20->setGeometry(QRect(490, 170, 113, 20));
        label_2 = new QLabel(Radio4);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(370, 30, 71, 16));
        lineEdit_21 = new QLineEdit(Radio4);
        lineEdit_21->setObjectName(QString::fromUtf8("lineEdit_21"));
        lineEdit_21->setGeometry(QRect(100, 200, 113, 20));
        label_4 = new QLabel(Radio4);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(480, 30, 111, 16));
        lineEdit_8 = new QLineEdit(Radio4);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(490, 80, 113, 20));
        lineEdit_40 = new QLineEdit(Radio4);
        lineEdit_40->setObjectName(QString::fromUtf8("lineEdit_40"));
        lineEdit_40->setGeometry(QRect(490, 320, 113, 20));
        lineEdit_17 = new QLineEdit(Radio4);
        lineEdit_17->setObjectName(QString::fromUtf8("lineEdit_17"));
        lineEdit_17->setGeometry(QRect(100, 170, 113, 20));
        lineEdit_30 = new QLineEdit(Radio4);
        lineEdit_30->setObjectName(QString::fromUtf8("lineEdit_30"));
        lineEdit_30->setGeometry(QRect(230, 260, 113, 20));
        lineEdit_19 = new QLineEdit(Radio4);
        lineEdit_19->setObjectName(QString::fromUtf8("lineEdit_19"));
        lineEdit_19->setGeometry(QRect(360, 170, 113, 20));
        lineEdit_32 = new QLineEdit(Radio4);
        lineEdit_32->setObjectName(QString::fromUtf8("lineEdit_32"));
        lineEdit_32->setGeometry(QRect(490, 260, 113, 20));
        lineEdit_27 = new QLineEdit(Radio4);
        lineEdit_27->setObjectName(QString::fromUtf8("lineEdit_27"));
        lineEdit_27->setGeometry(QRect(360, 230, 113, 20));
        label = new QLabel(Radio4);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(120, 30, 51, 16));
        lineEdit_37 = new QLineEdit(Radio4);
        lineEdit_37->setObjectName(QString::fromUtf8("lineEdit_37"));
        lineEdit_37->setGeometry(QRect(100, 320, 113, 20));
        lineEdit_16 = new QLineEdit(Radio4);
        lineEdit_16->setObjectName(QString::fromUtf8("lineEdit_16"));
        lineEdit_16->setGeometry(QRect(490, 140, 113, 20));
        lineEdit = new QLineEdit(Radio4);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(100, 50, 113, 20));
        lineEdit_24 = new QLineEdit(Radio4);
        lineEdit_24->setObjectName(QString::fromUtf8("lineEdit_24"));
        lineEdit_24->setGeometry(QRect(490, 200, 113, 20));
        lineEdit_26 = new QLineEdit(Radio4);
        lineEdit_26->setObjectName(QString::fromUtf8("lineEdit_26"));
        lineEdit_26->setGeometry(QRect(230, 230, 113, 20));
        lineEdit_35 = new QLineEdit(Radio4);
        lineEdit_35->setObjectName(QString::fromUtf8("lineEdit_35"));
        lineEdit_35->setGeometry(QRect(360, 290, 113, 20));
        lineEdit_28 = new QLineEdit(Radio4);
        lineEdit_28->setObjectName(QString::fromUtf8("lineEdit_28"));
        lineEdit_28->setGeometry(QRect(490, 230, 113, 20));
        pushButton = new QPushButton(Radio4);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(570, 400, 91, 23));
        lineEdit_14 = new QLineEdit(Radio4);
        lineEdit_14->setObjectName(QString::fromUtf8("lineEdit_14"));
        lineEdit_14->setGeometry(QRect(230, 140, 113, 20));
        lineEdit_9 = new QLineEdit(Radio4);
        lineEdit_9->setObjectName(QString::fromUtf8("lineEdit_9"));
        lineEdit_9->setGeometry(QRect(100, 110, 113, 20));
        lineEdit_31 = new QLineEdit(Radio4);
        lineEdit_31->setObjectName(QString::fromUtf8("lineEdit_31"));
        lineEdit_31->setGeometry(QRect(360, 260, 113, 20));
        lineEdit_29 = new QLineEdit(Radio4);
        lineEdit_29->setObjectName(QString::fromUtf8("lineEdit_29"));
        lineEdit_29->setGeometry(QRect(100, 260, 113, 20));
        lineEdit_18 = new QLineEdit(Radio4);
        lineEdit_18->setObjectName(QString::fromUtf8("lineEdit_18"));
        lineEdit_18->setGeometry(QRect(230, 170, 113, 20));
        lineEdit_15 = new QLineEdit(Radio4);
        lineEdit_15->setObjectName(QString::fromUtf8("lineEdit_15"));
        lineEdit_15->setGeometry(QRect(360, 140, 113, 20));
        lineEdit_11 = new QLineEdit(Radio4);
        lineEdit_11->setObjectName(QString::fromUtf8("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(360, 110, 113, 20));
        pushButton_2 = new QPushButton(Radio4);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(50, 400, 91, 23));
        lineEdit_39 = new QLineEdit(Radio4);
        lineEdit_39->setObjectName(QString::fromUtf8("lineEdit_39"));
        lineEdit_39->setGeometry(QRect(360, 320, 113, 20));
        lineEdit_5 = new QLineEdit(Radio4);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(100, 80, 113, 20));
        lineEdit_25 = new QLineEdit(Radio4);
        lineEdit_25->setObjectName(QString::fromUtf8("lineEdit_25"));
        lineEdit_25->setGeometry(QRect(100, 230, 113, 20));
        lineEdit_7 = new QLineEdit(Radio4);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(360, 80, 113, 20));
        lineEdit_38 = new QLineEdit(Radio4);
        lineEdit_38->setObjectName(QString::fromUtf8("lineEdit_38"));
        lineEdit_38->setGeometry(QRect(230, 320, 113, 20));

        retranslateUi(Radio4);

        QMetaObject::connectSlotsByName(Radio4);
    } // setupUi

    void retranslateUi(QWidget *Radio4)
    {
        Radio4->setWindowTitle(QCoreApplication::translate("Radio4", "Form", nullptr));
        label_3->setText(QCoreApplication::translate("Radio4", "\331\206\330\247\331\205 \330\256\330\247\331\206\331\210\330\247\330\257\332\257\333\214", nullptr));
        label_2->setText(QCoreApplication::translate("Radio4", "\330\264\331\205\330\247\330\261\331\207 \330\252\331\204\331\201\331\206", nullptr));
        label_4->setText(QCoreApplication::translate("Radio4", "\330\252\331\210\330\247\331\206\330\247\333\214\333\214 \330\256\330\261\333\214\330\257 \330\247\330\252\331\210\331\205\330\250\333\214\331\204", nullptr));
        label->setText(QCoreApplication::translate("Radio4", "\331\206\330\247\331\205", nullptr));
        pushButton->setText(QCoreApplication::translate("Radio4", "\331\206\331\205\330\247\333\214\330\264 \330\247\330\267\331\204\330\247\330\271\330\247\330\252", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Radio4", "\330\253\330\250\330\252 \330\252\330\272\333\214\333\214\330\261\330\247\330\252", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Radio4: public Ui_Radio4 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RADIO4_H
