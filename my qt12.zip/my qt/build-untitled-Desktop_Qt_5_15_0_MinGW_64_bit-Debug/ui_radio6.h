/********************************************************************************
** Form generated from reading UI file 'radio6.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RADIO6_H
#define UI_RADIO6_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Radio6
{
public:
    QLineEdit *lineEdit;
    QPushButton *pushButton;
    QFrame *frame;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLabel *label;

    void setupUi(QWidget *Radio6)
    {
        if (Radio6->objectName().isEmpty())
            Radio6->setObjectName(QString::fromUtf8("Radio6"));
        Radio6->resize(400, 300);
        Radio6->setMinimumSize(QSize(400, 300));
        Radio6->setMaximumSize(QSize(400, 300));
        Radio6->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        lineEdit = new QLineEdit(Radio6);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(80, 140, 251, 20));
        lineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton = new QPushButton(Radio6);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(160, 190, 91, 23));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        frame = new QFrame(Radio6);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(140, 40, 120, 80));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        lineEdit_2 = new QLineEdit(frame);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(10, 30, 41, 20));
        lineEdit_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_2->setMaxLength(2);
        lineEdit_3 = new QLineEdit(frame);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(70, 30, 41, 20));
        lineEdit_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_3->setMaxLength(4);
        label = new QLabel(Radio6);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 10, 351, 20));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        retranslateUi(Radio6);

        QMetaObject::connectSlotsByName(Radio6);
    } // setupUi

    void retranslateUi(QWidget *Radio6)
    {
        Radio6->setWindowTitle(QCoreApplication::translate("Radio6", "Form", nullptr));
        pushButton->setText(QCoreApplication::translate("Radio6", "\331\206\331\205\330\247\333\214\330\264 \330\247\330\267\331\204\330\247\330\271\330\247\330\252", nullptr));
        lineEdit_2->setPlaceholderText(QCoreApplication::translate("Radio6", "\331\205\330\247\331\207...", nullptr));
        lineEdit_3->setPlaceholderText(QCoreApplication::translate("Radio6", "\330\263\330\247\331\204...", nullptr));
        label->setText(QCoreApplication::translate("Radio6", "<html><head/><body><p>\330\254\331\207\330\252 \331\201\331\207\331\205\333\214\330\257\331\206 \330\257\330\261\330\242\331\205\330\257 \330\255\330\247\330\265\331\204 \330\247\330\262 \331\276\331\210\330\261\330\263\330\247\331\206\330\252 \330\256\331\210\330\257 \331\205\330\247\331\207 \331\210 \330\263\330\247\331\204 \331\205\331\210\330\261\330\257 \331\206\330\270\330\261 \330\261\330\247 \330\247\331\206\330\252\330\256\330\247\330\250 \332\251\331\206\333\214\330\257</p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Radio6: public Ui_Radio6 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RADIO6_H
