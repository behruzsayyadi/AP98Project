#ifndef RADIO6_H
#define RADIO6_H

#include <QWidget>

namespace Ui {
class Radio6;
}

class Radio6 : public QWidget
{
    Q_OBJECT

public:
    explicit Radio6(QWidget *parent = nullptr);
    ~Radio6();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Radio6 *ui;
};

#endif // RADIO6_H
