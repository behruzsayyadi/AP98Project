#include "radio3.h"
#include "ui_radio3.h"
#include<QFile>
#include<QTextStream>
#include<QString>

Radio3::Radio3(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Radio3)
{
    ui->setupUi(this);
}

Radio3::~Radio3()
{
    delete ui;
}

void Radio3::on_pushButton_clicked()
{
    if(ui->radioButton->isChecked()==true){
         QString text="";
    QFile myfile("allFile\\searchforcar.txt");
    if(!myfile.open(QFile::ReadOnly|QFile::Text)){
        text="این فایل باز نشد";
         ui->plainTextEdit->setPlainText(text);
    }
    else{
        QString name;
        QString rang;
        QString sale_tolid;
        QString gheymat;
        QString tarikh;
        QTextStream in(&myfile);

        for(long long int i=0;i<100;i++){
            name=in.readLine();
            rang=in.readLine();
            sale_tolid=in.readLine();
            gheymat=in.readLine();
            tarikh=in.readLine();
            if(ui->lineEdit->text()==name && ui->lineEdit_2->text()==rang && ui->lineEdit_3->text().toInt()<=sale_tolid.toInt() && sale_tolid.toInt()<=ui->lineEdit_4->text().toInt())
       {


       text= text+"نام اتومبیل :"+name+"\nرنگ اتومبیل:"+rang+"\nسال تولید اتومبیل:"+sale_tolid+"\nقیمت:"+gheymat+"\nتاریخ:"+tarikh+"\n*****************************";


         }



        }

    }

    ui->plainTextEdit->setPlainText(text);

    myfile.close();

}

    ///////////////////////////////////////////////////////////////


    else if(ui->radioButton_3->isChecked()==true){

        QString text="";
         int year=ui->lineEdit_7->text().toInt();
         int month=ui->lineEdit_8->text().toInt();
         QFile myfile1380("allFile\\memorandum\\"+QString::number(year)+QString::number(month) +".txt");
         if(!myfile1380.open(QFile::ReadOnly|QFile::Text)){
             ui->plainTextEdit->setPlainText("در همچین تاریخی قولنامه ای ثبت نشده است");
         }
         else{
             QTextStream in(&myfile1380);
             text=in.readAll();

         }
         ui->plainTextEdit->setPlainText(text);
         myfile1380.close();

    }
//////////////////////////////////////////////////////////
    else if(ui->radioButton_2->isChecked()==true){
        QString name=ui->lineEdit_5->text();
        QString family=ui->lineEdit_6->text();
        QFile myfile("allFile\\people\\"+name+" "+family+".txt");
        QTextStream in(&myfile);
        if(!myfile.open(QFile::ReadOnly|QFile::Text)){
            ui->plainTextEdit->setPlainText("همچین شخصی موجود نیست");
        }
        else{
            QString text=in.readAll();
            ui->plainTextEdit->setPlainText(text);
        }
        myfile.close();
    }
    ///////////////////////////////////////////////////////

}
