#include "radio6.h"
#include "ui_radio6.h"
#include<QFile>
#include<QTextStream>
#include<QString>

Radio6::Radio6(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Radio6)
{
    ui->setupUi(this);
}

Radio6::~Radio6()
{
    delete ui;
}

void Radio6::on_pushButton_clicked()
{
    int year=ui->lineEdit_3->text().toInt();
    int month=ui->lineEdit_2->text().toInt();
    QFile myfileEmad("allFile\\poorsantandnumber\\"+QString::number(year)+"\\"+QString::number(month)+".txt");
    if(!myfileEmad.open(QFile::ReadOnly|QFile::Text)){
        ui->lineEdit->setText("در چنین تاریخی پورسانتی دریافت نکرده اید");
    }
    else{
        double poorsant=0;
        QTextStream in(&myfileEmad);
        for(int i=0;i<100;i++){
            QString tedad=in.readLine();
            poorsant+=in.readLine().toDouble();
        }
        ui->lineEdit->setText((QString::number(poorsant/1000000))+"میلیون تومان");
    }
    myfileEmad.close();

}
