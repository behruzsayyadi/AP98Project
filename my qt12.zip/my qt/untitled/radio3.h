#ifndef RADIO3_H
#define RADIO3_H

#include <QWidget>

namespace Ui {
class Radio3;
}

class Radio3 : public QWidget
{
    Q_OBJECT

public:
    explicit Radio3(QWidget *parent = nullptr);
    ~Radio3();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Radio3 *ui;
};

#endif // RADIO3_H
