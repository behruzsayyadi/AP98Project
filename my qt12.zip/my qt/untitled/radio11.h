#ifndef RADIO11_H
#define RADIO11_H

#include <QWidget>

namespace Ui {
class Radio11;
}

class Radio11 : public QWidget
{
    Q_OBJECT

public:
    explicit Radio11(QWidget *parent = nullptr);
    ~Radio11();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Radio11 *ui;
};

#endif // RADIO11_H
