#ifndef RADIO10_H
#define RADIO10_H

#include <QWidget>

namespace Ui {
class Radio10;
}

class Radio10 : public QWidget
{
    Q_OBJECT

public:
    explicit Radio10(QWidget *parent = nullptr);
    ~Radio10();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Radio10 *ui;
};

#endif // RADIO10_H
