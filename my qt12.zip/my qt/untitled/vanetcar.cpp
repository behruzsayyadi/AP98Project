#include "vanetcar.h"

VanetCar::VanetCar()
{

}
double VanetCar::getpoorsant(double allmoney){
    return (0.015*allmoney);
}
