#include "radio5.h"
#include "ui_radio5.h"
#include"sabtchek.h"
#include<QFile>
#include<QTextStream>
#include<QString>
#include<QMessageBox>
#include<checkinfo.h>
#include<customer.h>
#include<seller.h>
#include"savari.h"
#include"vanetcar.h"
#include"shasiboland.h"
#include"dodar.h"
#include"korook.h"
#include"Memorandum.h"

Radio5::Radio5(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Radio5)
{
    ui->setupUi(this);
}

Radio5::~Radio5()
{
    delete ui;
}

void Radio5::on_pushButton_2_clicked()
{
    if(ui->radioButton_2->isChecked()==true){
        sabtchek*s=new sabtchek;
        s->setWindowTitle("ثبت اطلاعات چک");
        s->show();
    }
}

void Radio5::on_pushButton_clicked()
{








    //////////////////////////////////////////////////////////////چک های دریافتی
    int number=ui->lineEdit_33->text().toUInt();

    QFile myfile("allFile\\newChek.txt");
    if(!myfile.open(QFile::ReadOnly|QFile::Text)){

    }

    else{
    QTextStream in(&myfile);
    for(int i=0;i<number;i++){
        ch[i].setmoney(in.readLine());
        ch[i].setdate(in.readLine());
        ch[i].setshenase(in.readLine());

    }

    }

    myfile.close();
    /////////////////////////////////////////////////////////////////////چک های دریافتی











////////////////////////////////خریدار
se.setname(ui->lineEdit_21->text());
se.setfamily(ui->lineEdit_8->text());
se.setmobile(ui->lineEdit_9->text());
se.setkodemeli(ui->label_19->text());
se.sethomareshenas(ui->lineEdit_10->text());
se.settelephon(ui->lineEdit_13->text());
se.setbirhtday(ui->lineEdit_15->text());
se.setaddress(ui->lineEdit_27->text());
////////////////////////////////////خریدار


//////////////////////////////////////فروشنده
cu.setname(ui->lineEdit_32->text());
cu.setfamily(ui->lineEdit_25->text());
cu.setmobile(ui->lineEdit_29->text());
cu.setkodemeli(ui->label_22->text());
cu.sethomareshenas(ui->lineEdit_30->text());
cu.settelephon(ui->lineEdit_24->text());
cu.setbirhtday(ui->lineEdit_31->text());
cu.setaddress(ui->lineEdit_28->text());
/////////////////////////////////////////فروشنده






int year=ui->lineEdit_35->text().toInt();
int month=ui->lineEdit_36->text().toInt();
int day=ui->lineEdit_34->text().toInt();
int hour=ui->lineEdit_37->text().toInt();
int minuts=ui->lineEdit_38->text().toInt();
QString date1234=QString::number(day)+"/"+QString::number(month)+"/"+QString::number(year);


/////////////////////////////////////////اتومبیل

s.setname(ui->lineEdit_20->text());
s.setbrand(ui->lineEdit_18->text());
s.setrang(ui->lineEdit_17->text());
s.setInrang(ui->lineEdit_3->text());
s.setsanad(ui->lineEdit_4->text());
s.setshasi(ui->lineEdit_12->text());
s.setgheymat(ui->lineEdit_23->text());
s.setsal(ui->lineEdit_2->text());


 QFile myfile123456("allFile\\searchforcar.txt");
if(!myfile123456.open(QIODevice::Append)){

}
else{
    QTextStream out(&myfile123456);
    out<<s.getname()+"\n";
    out<<s.getrang()+"\n";
    out<<s.getsal()+"\n";
    out<<s.getgheymat()+"\n";
    out<<date1234+"\n";


}
myfile.flush();
myfile.close();

/////////////////////////////////////////////////مشخصات اتومبیل




poorsant=(0.01)*ui->lineEdit_12->text().toDouble();
/////////////////////////////////////////////////پورسانت اتومبیل
QString value=ui->comboBox_2->currentText();

if(value=="سواری"){

    poorsant=s.getpoorsant(ui->lineEdit_23->text().toDouble());


}
    else if(value=="شاسی"){

     poorsant=sh.getpoorsant(ui->lineEdit_23->text().toDouble());


    }

    else if(value=="وانت"){

    poorsant=v.getpoorsant(ui->lineEdit_23->text().toDouble());

    }
    else if(value=="کروک"){

   poorsant=k.getpoorsant(ui->lineEdit_23->text().toDouble());

    }

    else if(value=="دودر"){

    poorsant=d.getpoorsant(ui->lineEdit_23->text().toDouble());

    }

///////////////////////////////////////////////////////////////پورسانت اتومبیل


if(ui->radioButton_4->isChecked()==true){
QFile myfileEmad("allFile\\poorsantandnumber\\"+QString::number(year)+"\\"+QString::number(month)+".txt");
    myfileEmad.open(QIODevice::Append);
    QTextStream out(&myfileEmad);
    out<<"1\n";
    out<<QString::number(poorsant)+"\n";
    myfileEmad.flush();
    myfileEmad.close();


QMessageBox msg12;
msg12.setWindowTitle("پورسانت دریافتی");
msg12.setText("شما باید"+QString::number(poorsant/1000000)+"میلیون تومان پورسانت دریافت کنید");
msg12.exec();

}

else{
    QFile myfileEmad("allFile\\poorsantandnumber\\"+QString::number(year)+"\\"+QString::number(month)+".txt");
        myfileEmad.open(QIODevice::Append);
        QTextStream out(&myfileEmad);
        out<<"1\n";
        out<<"0\n";
        myfileEmad.flush();
        myfileEmad.close();


}










///////////////////////////////////////////////////////////////////ثبت اطلاعات خریدار و فروشنده
se.setinfoinfile();
cu.setinfoinfile();
////////////////////////////////////////////////////////////////////ثبت اطلاعات خریدار و فروشنده






//////////////////////////////////////////////////////////////////////////////////پیشنهاد برای فروش اتومبیل

QFile usefullfile("allFile\\usefullpeople.txt");
if(!usefullfile.open(QFile::ReadOnly|QFile::Text)){

}

else{
    QTextStream usefullin(&usefullfile);
    for(int i=0;i<10;i++){
        QString usename=usefullin.readLine();
        QString usefamily=usefullin.readLine();
        QString usemobile=usefullin.readLine();
        QString usemoney=usefullin.readLine();
        double usefullmoney=(usemoney.toDouble())/1000000;
        if(usefullmoney-50<=(ui->lineEdit_23->text().toDouble())/1000000&&(ui->lineEdit_23->text().toDouble())/1000000<=usefullmoney+50){
            QMessageBox msg1;
            msg1.setWindowTitle("پیشنهاد");
            msg1.setText("دنبال یک همچین اتومبیلی می گردد"+usename+usefamily);
            msg1.setInformativeText(usemobile+"تلفن همراه");
            msg1.exec();
        }

    }

}
usefullfile.close();

//////////////////////////////////////////////////////////////////////////////////پیشنهاد برای فروش اتومبیل



////////////////////////////////////////// ثبت قولنامه
memorandum(se,cu,s,year,month,day,hour,minuts,number);


//////////////////////////////////////////ثبت قولنامه





QMessageBox msg;
msg.setWindowTitle("ثبت");
msg.setText("با موفقیت ثبت شد");
msg.exec();








}
