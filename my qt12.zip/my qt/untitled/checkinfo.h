#ifndef CHECKINFO_H
#define CHECKINFO_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>

class Checkinfo
{
private:
    QString money;
    QString date;
    QString shenase;
public:
   Checkinfo(QString money,QString date,QString shenase);
    Checkinfo();
    void setmoney(QString money);
    void setdate(QString date);
    void setshenase(QString shenase);
    QString getmoney();
    QString getdate();
    QString getshenase();
};

#endif // CHECKINFO_H
