#include "radio.h"
#include "ui_radio.h"
#include<QFile>
#include<QString>
#include<QTextStream>
#include<QMessageBox>

Radio::Radio(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Radio)
{
    ui->setupUi(this);
    QString username="";
    QString password="";
    QFile myfile("allFile\\managerinfo.txt");
    if(!myfile.open(QFile::ReadOnly|QFile::Text)){


    }
    else{
        QTextStream in(&myfile);
        m.setname(in.readLine());
        m.setfamily(in.readLine());
        m.username=in.readLine();
        m.password=in.readLine();

    }

    ui->lineEdit->setPlaceholderText(m.username);
    ui->lineEdit_2->setPlaceholderText(m.password);
    myfile.close();




}

Radio::~Radio()
{
    delete ui;
}

void Radio::on_pushButton_clicked()
{
    QString username="";
    QString password="";
    username=ui->lineEdit->text();
    password=ui->lineEdit_2->text();

    QFile myfile("C:\\Users\\user\\Desktop\\allFile\\managerinfo.txt");

    if(!myfile.open(QFile::WriteOnly|QFile::Text)){


      }

else{

QTextStream out(&myfile);
QString text=username+"\n"+password;
out<<text;
myfile.flush();
myfile.close();
QMessageBox msg;
msg.setWindowTitle("ثبت شد");
msg.setText("تغییرات با موفقیت ثبت شد");
msg.exec();
}

}
