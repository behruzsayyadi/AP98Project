#ifndef RADIO8_H
#define RADIO8_H

#include <QWidget>

namespace Ui {
class Radio8;
}

class Radio8 : public QWidget
{
    Q_OBJECT

public:
    explicit Radio8(QWidget *parent = nullptr);
    ~Radio8();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Radio8 *ui;
};

#endif // RADIO8_H
