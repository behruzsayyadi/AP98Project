#include "radio8.h"
#include "ui_radio8.h"
#include<QFile>
#include<QTextStream>
#include<QString>
Radio8::Radio8(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Radio8)
{
    ui->setupUi(this);
}

Radio8::~Radio8()
{
    delete ui;
}

void Radio8::on_pushButton_clicked()
{
    double money[13];
    double max1=0;
    double min1=10000000000;
    int year=ui->lineEdit_3->text().toInt();
    for(int i=1;i<=12;i++){
        money[i]=0;
        int month=i;
    QFile myfileEmad("allFile\\poorsantandnumber\\"+QString::number(year)+"\\"+QString::number(month)+".txt");
    if(!myfileEmad.open(QFile::ReadOnly|QFile::Text)){
    money[i]=0;

    }
    else{
        QTextStream in(&myfileEmad);
    for(int j=0;j<20;j++){
        QString tedad=in.readLine();
        double money1=in.readLine().toDouble();
        money[i]+=money1;

        }
    }
      myfileEmad.close();
    }
    int mah=0;
    int mah1=0;
    for(int i=1;i<=12;i++){
        if(money[i]>=max1){
            max1=money[i];
            mah=i;
        }
        if(money[i]<min1){
            min1=money[i];
            mah1=i;
        }

    }
    ui->lineEdit->setText(QString::number(mah));
    ui->lineEdit_2->setText(QString::number(mah1));


    }



