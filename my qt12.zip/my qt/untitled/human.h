#ifndef HUMAN_H
#define HUMAN_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>

class Human
{
protected:
    QString name;
    QString family;
public:
    Human();
    Human(QString name,QString family);
};


#endif // HUMAN_H
