#include "radio11.h"
#include "ui_radio11.h"
#include<QFile>
#include<QTextStream>
#include<QString>

Radio11::Radio11(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Radio11)
{
    ui->setupUi(this);
}

Radio11::~Radio11()
{
    delete ui;
}

void Radio11::on_pushButton_clicked()
{
    int year=ui->lineEdit_3->text().toInt();
    int month=ui->lineEdit_2->text().toInt();
    QFile myfileEmad("allFile\\poorsantandnumber\\"+QString::number(year)+"\\"+QString::number(month)+".txt");
    if(!myfileEmad.open(QFile::ReadOnly|QFile::Text)){
        ui->lineEdit->setText("در چنین تاریخی خرید و فروشی نکرده اید");
    }
    else{
        int tedad=0;
        QTextStream in(&myfileEmad);
        for(int i=0;i<100;i++){
            tedad+=in.readLine().toInt();
            QString poorsant=in.readLine();

        }
        ui->lineEdit->setText((QString::number(tedad))+"خرید و فروش شده");
    }
    myfileEmad.close();

}
