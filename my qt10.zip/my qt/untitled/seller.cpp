#include "seller.h"
#include<QFile>
#include<QTextStream>
#include<QString>

Seller::Seller()
{

}
void Seller:: setname(QString name){
    this->name=name;
}
void Seller:: setfamily(QString family){
    this->family=family;
}
void Seller:: setkodemeli(QString kodemeli){
    this->kode_meli=kodemeli;
}
void Seller:: sethomareshenas(QString shomare){
    this->shomare_shenas=shomare;
}
void Seller:: setaddress(QString address){
    this->Address=address;
}
void Seller:: settelephon(QString telephon){
    this->telephon=telephon;
}
void Seller:: setmobile(QString mobile){
    this->mobile=mobile;
}
void Seller:: setbirhtday(QString birhday){
    this->birthday=birhday;
}
QString Seller:: getname(){
    return name;
}
QString Seller:: getfamily(){
    return family;
}
QString Seller:: getkodemeli(){
    return kode_meli;
}
QString Seller:: gethomareshenas(){
    return shomare_shenas;
}
QString Seller:: getaddress(){
    return Address;
}
QString Seller:: gettelephon(){
return telephon;
}
QString Seller:: getmobile(){
    return mobile;
}
QString Seller:: getbirhtday(){
    return birthday;
}

void Seller::setinfoinfile(){
   QFile myfile("C:\\Users\\user\\Desktop\\allFile\\people\\"+this->name+" "+this->family+".txt");
   QString text;
   QTextStream out(&myfile);
   if(!myfile.open(QFile::WriteOnly|QFile::Text)){

   }
   else{
       out<<"Name:"+name+"\t";
       out<<"Family:"+family+"\n";
       out<<"Identity Code1:"+kode_meli+"\t";
       out<<"Identity Code2"+shomare_shenas+"\n";
       out<<"Birthday:"+birthday+"\t";
       out<<"Address:"+Address+"\n";
       out<<"Mobile number:"+mobile+"\t";
       out<<"Telephon number:"+telephon+"\n";

   }

   myfile.flush();
   myfile.close();


}

