#ifndef KOROOK_H
#define KOROOK_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include"car.h"

class Korook:public Car
{
private:
    double poorsant;
public:
    Korook();
     double getpoorsant(double allmoney);
};

#endif // KOROOK_H
