#include "customer.h"
#include<QString>
#include<QTextStream>
#include<QFile>

Customer::Customer()
{

}
void Customer:: setname(QString name){
    this->name=name;
}
void Customer:: setfamily(QString family){
    this->family=family;
}
void Customer:: setkodemeli(QString kodemeli){
    this->kode_meli=kodemeli;
}
void Customer:: sethomareshenas(QString shomare){
    this->shomare_shenas=shomare;
}
void Customer:: setaddress(QString address){
    this->Address=address;
}
void Customer:: settelephon(QString telephon){
    this->telephon=telephon;
}
void Customer:: setmobile(QString mobile){
    this->mobile=mobile;
}
void Customer:: setbirhtday(QString birhday){
    this->birthday=birhday;
}
QString Customer:: getname(){
    return name;
}
QString Customer:: getfamily(){
    return family;
}
QString Customer:: getkodemeli(){
    return kode_meli;
}
QString Customer:: gethomareshenas(){
    return shomare_shenas;
}
QString Customer:: getaddress(){
    return Address;
}
QString Customer:: gettelephon(){
return telephon;
}
QString Customer:: getmobile(){
    return mobile;
}
QString Customer:: getbirhtday(){
    return birthday;
}

void Customer::setinfoinfile(){
   QFile myfile("C:\\Users\\user\\Desktop\\allFile\\people\\"+this->name+" "+this->family+".txt");
   QString text;
   QTextStream out(&myfile);
   if(!myfile.open(QFile::WriteOnly|QFile::Text)){

   }
   else{
       out<<"Name:"+name+"\t";
       out<<"Family:"+family+"\n";
       out<<"Identity Code1:"+kode_meli+"\t";
       out<<"Identity Code2"+shomare_shenas+"\n";
       out<<"Birthday:"+birthday+"\t";
       out<<"Address:"+Address+"\n";
       out<<"Mobile number:"+mobile+"\t";
       out<<"Telephon number:"+telephon+"\n";

   }

   myfile.flush();
   myfile.close();


}
