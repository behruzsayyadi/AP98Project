#ifndef AUTOGALLERY_H
#define AUTOGALLERY_H
#include <QMainWindow>
#include <QObject>
#include <QWidget>

class AutoGallery
{
private:
    QString nameofauto;
    QString Addressofauto;
    QString Telephonofauto;
    QString nameofmanager;
public:
    AutoGallery();
    void setnameauto(QString autoname);
    void setaddres(QString address);
    void settelephon(QString telephon);
    void setmangername(QString managername);
    QString getnameauto();
    QString getaddress();
    QString gettelephon();
    QString getmangername();

};

#endif // AUTOGALLERY_H
