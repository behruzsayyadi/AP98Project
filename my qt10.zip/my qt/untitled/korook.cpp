#include "korook.h"

Korook::Korook()
{

}
double Korook::getpoorsant(double allmoney){
    return (0.03*allmoney);
}
