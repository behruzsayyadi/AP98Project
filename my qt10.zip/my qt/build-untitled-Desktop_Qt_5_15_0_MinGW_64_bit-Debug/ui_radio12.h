/********************************************************************************
** Form generated from reading UI file 'radio12.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RADIO12_H
#define UI_RADIO12_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Radio12
{
public:
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_8;
    QLineEdit *lineEdit_9;
    QLineEdit *lineEdit_10;
    QLineEdit *lineEdit_11;
    QLineEdit *lineEdit_12;
    QLineEdit *lineEdit_13;
    QLineEdit *lineEdit_14;
    QLineEdit *lineEdit_15;
    QLineEdit *lineEdit_16;
    QLineEdit *lineEdit_17;
    QLineEdit *lineEdit_18;
    QLineEdit *lineEdit_19;
    QLineEdit *lineEdit_20;
    QLineEdit *lineEdit_21;
    QLineEdit *lineEdit_22;
    QLineEdit *lineEdit_23;
    QLineEdit *lineEdit_24;
    QLineEdit *lineEdit_25;
    QLineEdit *lineEdit_26;
    QLineEdit *lineEdit_27;
    QLineEdit *lineEdit_28;
    QLineEdit *lineEdit_29;
    QLineEdit *lineEdit_30;
    QLineEdit *lineEdit_31;
    QLineEdit *lineEdit_32;
    QLineEdit *lineEdit_33;
    QLineEdit *lineEdit_34;
    QLineEdit *lineEdit_35;
    QLineEdit *lineEdit_36;
    QLineEdit *lineEdit_37;
    QLineEdit *lineEdit_38;
    QLineEdit *lineEdit_39;
    QLineEdit *lineEdit_40;
    QLineEdit *lineEdit_41;
    QLineEdit *lineEdit_42;
    QLineEdit *lineEdit_43;
    QLineEdit *lineEdit_44;
    QLineEdit *lineEdit_45;
    QLineEdit *lineEdit_46;
    QLineEdit *lineEdit_47;
    QLineEdit *lineEdit_48;
    QLineEdit *lineEdit_49;
    QLineEdit *lineEdit_50;
    QLineEdit *lineEdit_51;
    QLineEdit *lineEdit_52;
    QLineEdit *lineEdit_53;
    QLineEdit *lineEdit_54;
    QLineEdit *lineEdit_55;
    QLineEdit *lineEdit_56;
    QLineEdit *lineEdit_57;
    QLineEdit *lineEdit_58;
    QLineEdit *lineEdit_59;
    QLineEdit *lineEdit_60;
    QLineEdit *lineEdit_61;
    QLineEdit *lineEdit_62;
    QLineEdit *lineEdit_63;
    QLineEdit *lineEdit_64;
    QLineEdit *lineEdit_65;
    QLineEdit *lineEdit_66;
    QLineEdit *lineEdit_67;
    QLineEdit *lineEdit_68;
    QLineEdit *lineEdit_69;
    QLabel *label;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QPushButton *pushButton;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *label_17;
    QLabel *label_18;
    QLabel *label_19;
    QLineEdit *lineEdit_70;
    QPushButton *pushButton_2;

    void setupUi(QWidget *Radio12)
    {
        if (Radio12->objectName().isEmpty())
            Radio12->setObjectName(QString::fromUtf8("Radio12"));
        Radio12->resize(736, 542);
        lineEdit = new QLineEdit(Radio12);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(26, 80, 151, 20));
        lineEdit->setReadOnly(true);
        lineEdit_2 = new QLineEdit(Radio12);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(194, 80, 113, 20));
        lineEdit_2->setReadOnly(true);
        lineEdit_3 = new QLineEdit(Radio12);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(324, 80, 113, 20));
        lineEdit_3->setReadOnly(true);
        lineEdit_4 = new QLineEdit(Radio12);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(454, 80, 113, 20));
        lineEdit_4->setReadOnly(true);
        lineEdit_5 = new QLineEdit(Radio12);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(584, 80, 113, 20));
        lineEdit_5->setReadOnly(true);
        lineEdit_6 = new QLineEdit(Radio12);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(12, 260, 171, 20));
        lineEdit_7 = new QLineEdit(Radio12);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(190, 260, 41, 20));
        lineEdit_8 = new QLineEdit(Radio12);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(240, 260, 41, 20));
        lineEdit_9 = new QLineEdit(Radio12);
        lineEdit_9->setObjectName(QString::fromUtf8("lineEdit_9"));
        lineEdit_9->setGeometry(QRect(290, 260, 41, 20));
        lineEdit_10 = new QLineEdit(Radio12);
        lineEdit_10->setObjectName(QString::fromUtf8("lineEdit_10"));
        lineEdit_10->setGeometry(QRect(10, 290, 171, 20));
        lineEdit_11 = new QLineEdit(Radio12);
        lineEdit_11->setObjectName(QString::fromUtf8("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(190, 290, 41, 20));
        lineEdit_12 = new QLineEdit(Radio12);
        lineEdit_12->setObjectName(QString::fromUtf8("lineEdit_12"));
        lineEdit_12->setGeometry(QRect(240, 290, 41, 20));
        lineEdit_13 = new QLineEdit(Radio12);
        lineEdit_13->setObjectName(QString::fromUtf8("lineEdit_13"));
        lineEdit_13->setGeometry(QRect(290, 290, 41, 20));
        lineEdit_14 = new QLineEdit(Radio12);
        lineEdit_14->setObjectName(QString::fromUtf8("lineEdit_14"));
        lineEdit_14->setGeometry(QRect(10, 320, 171, 20));
        lineEdit_15 = new QLineEdit(Radio12);
        lineEdit_15->setObjectName(QString::fromUtf8("lineEdit_15"));
        lineEdit_15->setGeometry(QRect(190, 320, 41, 20));
        lineEdit_16 = new QLineEdit(Radio12);
        lineEdit_16->setObjectName(QString::fromUtf8("lineEdit_16"));
        lineEdit_16->setGeometry(QRect(240, 320, 41, 20));
        lineEdit_17 = new QLineEdit(Radio12);
        lineEdit_17->setObjectName(QString::fromUtf8("lineEdit_17"));
        lineEdit_17->setGeometry(QRect(290, 320, 41, 20));
        lineEdit_18 = new QLineEdit(Radio12);
        lineEdit_18->setObjectName(QString::fromUtf8("lineEdit_18"));
        lineEdit_18->setGeometry(QRect(10, 350, 171, 20));
        lineEdit_19 = new QLineEdit(Radio12);
        lineEdit_19->setObjectName(QString::fromUtf8("lineEdit_19"));
        lineEdit_19->setGeometry(QRect(190, 350, 41, 20));
        lineEdit_20 = new QLineEdit(Radio12);
        lineEdit_20->setObjectName(QString::fromUtf8("lineEdit_20"));
        lineEdit_20->setGeometry(QRect(240, 350, 41, 20));
        lineEdit_21 = new QLineEdit(Radio12);
        lineEdit_21->setObjectName(QString::fromUtf8("lineEdit_21"));
        lineEdit_21->setGeometry(QRect(290, 350, 41, 20));
        lineEdit_22 = new QLineEdit(Radio12);
        lineEdit_22->setObjectName(QString::fromUtf8("lineEdit_22"));
        lineEdit_22->setGeometry(QRect(10, 380, 171, 20));
        lineEdit_23 = new QLineEdit(Radio12);
        lineEdit_23->setObjectName(QString::fromUtf8("lineEdit_23"));
        lineEdit_23->setGeometry(QRect(190, 380, 41, 20));
        lineEdit_24 = new QLineEdit(Radio12);
        lineEdit_24->setObjectName(QString::fromUtf8("lineEdit_24"));
        lineEdit_24->setGeometry(QRect(240, 380, 41, 20));
        lineEdit_25 = new QLineEdit(Radio12);
        lineEdit_25->setObjectName(QString::fromUtf8("lineEdit_25"));
        lineEdit_25->setGeometry(QRect(290, 380, 41, 20));
        lineEdit_26 = new QLineEdit(Radio12);
        lineEdit_26->setObjectName(QString::fromUtf8("lineEdit_26"));
        lineEdit_26->setGeometry(QRect(10, 410, 171, 20));
        lineEdit_27 = new QLineEdit(Radio12);
        lineEdit_27->setObjectName(QString::fromUtf8("lineEdit_27"));
        lineEdit_27->setGeometry(QRect(190, 410, 41, 20));
        lineEdit_28 = new QLineEdit(Radio12);
        lineEdit_28->setObjectName(QString::fromUtf8("lineEdit_28"));
        lineEdit_28->setGeometry(QRect(240, 410, 41, 20));
        lineEdit_29 = new QLineEdit(Radio12);
        lineEdit_29->setObjectName(QString::fromUtf8("lineEdit_29"));
        lineEdit_29->setGeometry(QRect(290, 410, 41, 20));
        lineEdit_30 = new QLineEdit(Radio12);
        lineEdit_30->setObjectName(QString::fromUtf8("lineEdit_30"));
        lineEdit_30->setGeometry(QRect(10, 440, 171, 20));
        lineEdit_31 = new QLineEdit(Radio12);
        lineEdit_31->setObjectName(QString::fromUtf8("lineEdit_31"));
        lineEdit_31->setGeometry(QRect(190, 440, 41, 20));
        lineEdit_32 = new QLineEdit(Radio12);
        lineEdit_32->setObjectName(QString::fromUtf8("lineEdit_32"));
        lineEdit_32->setGeometry(QRect(240, 440, 41, 20));
        lineEdit_33 = new QLineEdit(Radio12);
        lineEdit_33->setObjectName(QString::fromUtf8("lineEdit_33"));
        lineEdit_33->setGeometry(QRect(290, 440, 41, 20));
        lineEdit_34 = new QLineEdit(Radio12);
        lineEdit_34->setObjectName(QString::fromUtf8("lineEdit_34"));
        lineEdit_34->setGeometry(QRect(10, 470, 171, 20));
        lineEdit_35 = new QLineEdit(Radio12);
        lineEdit_35->setObjectName(QString::fromUtf8("lineEdit_35"));
        lineEdit_35->setGeometry(QRect(190, 470, 41, 20));
        lineEdit_36 = new QLineEdit(Radio12);
        lineEdit_36->setObjectName(QString::fromUtf8("lineEdit_36"));
        lineEdit_36->setGeometry(QRect(240, 470, 41, 20));
        lineEdit_37 = new QLineEdit(Radio12);
        lineEdit_37->setObjectName(QString::fromUtf8("lineEdit_37"));
        lineEdit_37->setGeometry(QRect(290, 470, 41, 20));
        lineEdit_38 = new QLineEdit(Radio12);
        lineEdit_38->setObjectName(QString::fromUtf8("lineEdit_38"));
        lineEdit_38->setGeometry(QRect(390, 260, 171, 20));
        lineEdit_39 = new QLineEdit(Radio12);
        lineEdit_39->setObjectName(QString::fromUtf8("lineEdit_39"));
        lineEdit_39->setGeometry(QRect(570, 260, 41, 20));
        lineEdit_40 = new QLineEdit(Radio12);
        lineEdit_40->setObjectName(QString::fromUtf8("lineEdit_40"));
        lineEdit_40->setGeometry(QRect(620, 260, 41, 20));
        lineEdit_41 = new QLineEdit(Radio12);
        lineEdit_41->setObjectName(QString::fromUtf8("lineEdit_41"));
        lineEdit_41->setGeometry(QRect(670, 260, 41, 20));
        lineEdit_42 = new QLineEdit(Radio12);
        lineEdit_42->setObjectName(QString::fromUtf8("lineEdit_42"));
        lineEdit_42->setGeometry(QRect(390, 290, 171, 20));
        lineEdit_43 = new QLineEdit(Radio12);
        lineEdit_43->setObjectName(QString::fromUtf8("lineEdit_43"));
        lineEdit_43->setGeometry(QRect(570, 290, 41, 20));
        lineEdit_44 = new QLineEdit(Radio12);
        lineEdit_44->setObjectName(QString::fromUtf8("lineEdit_44"));
        lineEdit_44->setGeometry(QRect(620, 290, 41, 20));
        lineEdit_45 = new QLineEdit(Radio12);
        lineEdit_45->setObjectName(QString::fromUtf8("lineEdit_45"));
        lineEdit_45->setGeometry(QRect(670, 290, 41, 20));
        lineEdit_46 = new QLineEdit(Radio12);
        lineEdit_46->setObjectName(QString::fromUtf8("lineEdit_46"));
        lineEdit_46->setGeometry(QRect(390, 320, 171, 20));
        lineEdit_47 = new QLineEdit(Radio12);
        lineEdit_47->setObjectName(QString::fromUtf8("lineEdit_47"));
        lineEdit_47->setGeometry(QRect(570, 320, 41, 20));
        lineEdit_48 = new QLineEdit(Radio12);
        lineEdit_48->setObjectName(QString::fromUtf8("lineEdit_48"));
        lineEdit_48->setGeometry(QRect(620, 320, 41, 20));
        lineEdit_49 = new QLineEdit(Radio12);
        lineEdit_49->setObjectName(QString::fromUtf8("lineEdit_49"));
        lineEdit_49->setGeometry(QRect(670, 320, 41, 20));
        lineEdit_50 = new QLineEdit(Radio12);
        lineEdit_50->setObjectName(QString::fromUtf8("lineEdit_50"));
        lineEdit_50->setGeometry(QRect(390, 350, 171, 20));
        lineEdit_51 = new QLineEdit(Radio12);
        lineEdit_51->setObjectName(QString::fromUtf8("lineEdit_51"));
        lineEdit_51->setGeometry(QRect(570, 350, 41, 20));
        lineEdit_52 = new QLineEdit(Radio12);
        lineEdit_52->setObjectName(QString::fromUtf8("lineEdit_52"));
        lineEdit_52->setGeometry(QRect(620, 350, 41, 20));
        lineEdit_53 = new QLineEdit(Radio12);
        lineEdit_53->setObjectName(QString::fromUtf8("lineEdit_53"));
        lineEdit_53->setGeometry(QRect(670, 350, 41, 20));
        lineEdit_54 = new QLineEdit(Radio12);
        lineEdit_54->setObjectName(QString::fromUtf8("lineEdit_54"));
        lineEdit_54->setGeometry(QRect(390, 380, 171, 20));
        lineEdit_55 = new QLineEdit(Radio12);
        lineEdit_55->setObjectName(QString::fromUtf8("lineEdit_55"));
        lineEdit_55->setGeometry(QRect(570, 380, 41, 20));
        lineEdit_56 = new QLineEdit(Radio12);
        lineEdit_56->setObjectName(QString::fromUtf8("lineEdit_56"));
        lineEdit_56->setGeometry(QRect(620, 380, 41, 20));
        lineEdit_57 = new QLineEdit(Radio12);
        lineEdit_57->setObjectName(QString::fromUtf8("lineEdit_57"));
        lineEdit_57->setGeometry(QRect(670, 380, 41, 20));
        lineEdit_58 = new QLineEdit(Radio12);
        lineEdit_58->setObjectName(QString::fromUtf8("lineEdit_58"));
        lineEdit_58->setGeometry(QRect(390, 410, 171, 20));
        lineEdit_59 = new QLineEdit(Radio12);
        lineEdit_59->setObjectName(QString::fromUtf8("lineEdit_59"));
        lineEdit_59->setGeometry(QRect(570, 410, 41, 20));
        lineEdit_60 = new QLineEdit(Radio12);
        lineEdit_60->setObjectName(QString::fromUtf8("lineEdit_60"));
        lineEdit_60->setGeometry(QRect(620, 410, 41, 20));
        lineEdit_61 = new QLineEdit(Radio12);
        lineEdit_61->setObjectName(QString::fromUtf8("lineEdit_61"));
        lineEdit_61->setGeometry(QRect(670, 410, 41, 20));
        lineEdit_62 = new QLineEdit(Radio12);
        lineEdit_62->setObjectName(QString::fromUtf8("lineEdit_62"));
        lineEdit_62->setGeometry(QRect(392, 440, 171, 20));
        lineEdit_63 = new QLineEdit(Radio12);
        lineEdit_63->setObjectName(QString::fromUtf8("lineEdit_63"));
        lineEdit_63->setGeometry(QRect(570, 440, 41, 20));
        lineEdit_64 = new QLineEdit(Radio12);
        lineEdit_64->setObjectName(QString::fromUtf8("lineEdit_64"));
        lineEdit_64->setGeometry(QRect(620, 440, 41, 20));
        lineEdit_65 = new QLineEdit(Radio12);
        lineEdit_65->setObjectName(QString::fromUtf8("lineEdit_65"));
        lineEdit_65->setGeometry(QRect(670, 440, 41, 20));
        lineEdit_66 = new QLineEdit(Radio12);
        lineEdit_66->setObjectName(QString::fromUtf8("lineEdit_66"));
        lineEdit_66->setGeometry(QRect(390, 470, 171, 20));
        lineEdit_67 = new QLineEdit(Radio12);
        lineEdit_67->setObjectName(QString::fromUtf8("lineEdit_67"));
        lineEdit_67->setGeometry(QRect(570, 470, 41, 20));
        lineEdit_68 = new QLineEdit(Radio12);
        lineEdit_68->setObjectName(QString::fromUtf8("lineEdit_68"));
        lineEdit_68->setGeometry(QRect(620, 470, 41, 20));
        lineEdit_69 = new QLineEdit(Radio12);
        lineEdit_69->setObjectName(QString::fromUtf8("lineEdit_69"));
        lineEdit_69->setGeometry(QRect(670, 470, 41, 20));
        label = new QLabel(Radio12);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(70, 240, 47, 13));
        label_9 = new QLabel(Radio12);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(54, 50, 81, 16));
        label_10 = new QLabel(Radio12);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(214, 50, 61, 16));
        label_11 = new QLabel(Radio12);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(334, 50, 71, 16));
        label_12 = new QLabel(Radio12);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(484, 50, 47, 13));
        label_13 = new QLabel(Radio12);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(590, 50, 91, 20));
        label_14 = new QLabel(Radio12);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(250, 140, 51, 20));
        label_5 = new QLabel(Radio12);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(660, 240, 47, 13));
        label_6 = new QLabel(Radio12);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(550, 240, 47, 13));
        label_7 = new QLabel(Radio12);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(600, 240, 47, 13));
        label_8 = new QLabel(Radio12);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(450, 240, 47, 13));
        pushButton = new QPushButton(Radio12);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(50, 510, 75, 23));
        label_15 = new QLabel(Radio12);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(270, 10, 161, 16));
        label_16 = new QLabel(Radio12);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(270, 210, 161, 16));
        label_17 = new QLabel(Radio12);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(210, 240, 47, 13));
        label_18 = new QLabel(Radio12);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(270, 240, 47, 13));
        label_19 = new QLabel(Radio12);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(160, 240, 47, 13));
        lineEdit_70 = new QLineEdit(Radio12);
        lineEdit_70->setObjectName(QString::fromUtf8("lineEdit_70"));
        lineEdit_70->setGeometry(QRect(310, 140, 113, 20));
        lineEdit_70->setReadOnly(true);
        pushButton_2 = new QPushButton(Radio12);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(604, 510, 91, 23));

        retranslateUi(Radio12);

        QMetaObject::connectSlotsByName(Radio12);
    } // setupUi

    void retranslateUi(QWidget *Radio12)
    {
        Radio12->setWindowTitle(QCoreApplication::translate("Radio12", "Form", nullptr));
        label->setText(QCoreApplication::translate("Radio12", "\331\205\331\206\330\247\330\263\330\250\330\252", nullptr));
        label_9->setText(QCoreApplication::translate("Radio12", "\331\206\330\247\331\205 \331\210\331\206\330\247\331\205 \330\256\330\247\331\206\331\210\330\247\330\257\332\257\333\214", nullptr));
        label_10->setText(QCoreApplication::translate("Radio12", "\330\264\331\205\330\247\330\261\331\207 \330\252\331\204\331\201\331\206", nullptr));
        label_11->setText(QCoreApplication::translate("Radio12", "\330\264\331\205\330\247\330\261\331\207 \331\205\331\210\330\250\330\247\333\214\331\204", nullptr));
        label_12->setText(QCoreApplication::translate("Radio12", "\332\251\330\257 \331\205\331\204\333\214", nullptr));
        label_13->setText(QCoreApplication::translate("Radio12", "\330\264\331\205\330\247\330\261\331\207 \330\264\331\206\330\247\330\263\331\206\330\247\331\205\331\207", nullptr));
        label_14->setText(QCoreApplication::translate("Radio12", "\330\252\330\247\330\261\333\214\330\256 \330\252\331\210\331\204\330\257", nullptr));
        label_5->setText(QCoreApplication::translate("Radio12", "\330\263\330\247\331\204", nullptr));
        label_6->setText(QCoreApplication::translate("Radio12", "\330\261\331\210\330\262", nullptr));
        label_7->setText(QCoreApplication::translate("Radio12", "\331\205\330\247\331\207", nullptr));
        label_8->setText(QCoreApplication::translate("Radio12", "\331\205\331\206\330\247\330\263\330\250\330\252", nullptr));
        pushButton->setText(QCoreApplication::translate("Radio12", "\330\253\330\250\330\252 \330\252\330\272\333\214\333\214\330\261\330\247\330\252", nullptr));
        label_15->setText(QCoreApplication::translate("Radio12", "\330\247\330\267\331\204\330\247\330\271\330\247\330\252 \330\264\330\256\330\265\333\214 \330\265\330\247\330\255\330\250 \331\206\331\205\330\247\333\214\330\264\332\257\330\247\331\207", nullptr));
        label_16->setText(QCoreApplication::translate("Radio12", "\330\253\330\250\330\252 \330\261\331\210\333\214\330\257\330\247\330\257 \331\207\330\247\333\214 \331\205\331\207\331\205 \330\250\330\261\330\247\333\214 \330\264\331\205\330\247", nullptr));
        label_17->setText(QCoreApplication::translate("Radio12", "\331\205\330\247\331\207", nullptr));
        label_18->setText(QCoreApplication::translate("Radio12", "\330\263\330\247\331\204", nullptr));
        label_19->setText(QCoreApplication::translate("Radio12", "\330\261\331\210\330\262", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Radio12", "\331\206\331\205\330\247\333\214\330\264 \330\247\330\267\331\204\330\247\330\271\330\247\330\252", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Radio12: public Ui_Radio12 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RADIO12_H
