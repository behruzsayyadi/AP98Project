/********************************************************************************
** Form generated from reading UI file 'radio5.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RADIO5_H
#define UI_RADIO5_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Radio5
{
public:
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_11;
    QLineEdit *lineEdit_12;
    QLineEdit *lineEdit_14;
    QLineEdit *lineEdit_15;
    QLineEdit *lineEdit_16;
    QLineEdit *lineEdit_17;
    QLineEdit *lineEdit_18;
    QLineEdit *lineEdit_20;
    QLineEdit *lineEdit_23;
    QComboBox *comboBox_2;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit_8;
    QLineEdit *lineEdit_19;
    QLineEdit *lineEdit_13;
    QLineEdit *lineEdit_9;
    QLineEdit *lineEdit_10;
    QLineEdit *lineEdit_21;
    QLineEdit *lineEdit_22;
    QLineEdit *lineEdit_24;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton;
    QFrame *frame;
    QLabel *label_3;
    QPushButton *pushButton_2;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QLabel *label_4;
    QLineEdit *lineEdit_25;

    void setupUi(QWidget *Radio5)
    {
        if (Radio5->objectName().isEmpty())
            Radio5->setObjectName(QString::fromUtf8("Radio5"));
        Radio5->resize(735, 478);
        Radio5->setMinimumSize(QSize(735, 478));
        Radio5->setMaximumSize(QSize(735, 478));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../\330\256\330\261\333\214\330\257+\330\250\331\206\330\2621.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        Radio5->setWindowIcon(icon);
        Radio5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit = new QLineEdit(Radio5);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(60, 90, 113, 20));
        lineEdit_3 = new QLineEdit(Radio5);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(280, 170, 113, 20));
        lineEdit_4 = new QLineEdit(Radio5);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(280, 210, 113, 20));
        lineEdit_5 = new QLineEdit(Radio5);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(60, 210, 113, 20));
        lineEdit_6 = new QLineEdit(Radio5);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(60, 130, 113, 20));
        lineEdit_7 = new QLineEdit(Radio5);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(60, 50, 113, 20));
        lineEdit_11 = new QLineEdit(Radio5);
        lineEdit_11->setObjectName(QString::fromUtf8("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(60, 290, 113, 20));
        lineEdit_12 = new QLineEdit(Radio5);
        lineEdit_12->setObjectName(QString::fromUtf8("lineEdit_12"));
        lineEdit_12->setGeometry(QRect(280, 250, 113, 20));
        lineEdit_14 = new QLineEdit(Radio5);
        lineEdit_14->setObjectName(QString::fromUtf8("lineEdit_14"));
        lineEdit_14->setGeometry(QRect(60, 330, 113, 20));
        lineEdit_15 = new QLineEdit(Radio5);
        lineEdit_15->setObjectName(QString::fromUtf8("lineEdit_15"));
        lineEdit_15->setGeometry(QRect(60, 250, 113, 20));
        lineEdit_16 = new QLineEdit(Radio5);
        lineEdit_16->setObjectName(QString::fromUtf8("lineEdit_16"));
        lineEdit_16->setGeometry(QRect(60, 170, 113, 20));
        lineEdit_17 = new QLineEdit(Radio5);
        lineEdit_17->setObjectName(QString::fromUtf8("lineEdit_17"));
        lineEdit_17->setGeometry(QRect(280, 130, 113, 20));
        lineEdit_18 = new QLineEdit(Radio5);
        lineEdit_18->setObjectName(QString::fromUtf8("lineEdit_18"));
        lineEdit_18->setGeometry(QRect(280, 90, 113, 20));
        lineEdit_20 = new QLineEdit(Radio5);
        lineEdit_20->setObjectName(QString::fromUtf8("lineEdit_20"));
        lineEdit_20->setGeometry(QRect(280, 50, 113, 20));
        lineEdit_23 = new QLineEdit(Radio5);
        lineEdit_23->setObjectName(QString::fromUtf8("lineEdit_23"));
        lineEdit_23->setGeometry(QRect(280, 290, 113, 20));
        comboBox_2 = new QComboBox(Radio5);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        comboBox_2->setGeometry(QRect(280, 10, 111, 22));
        label = new QLabel(Radio5);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(90, 20, 47, 13));
        label_2 = new QLabel(Radio5);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(550, 20, 47, 13));
        lineEdit_8 = new QLineEdit(Radio5);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(520, 90, 113, 20));
        lineEdit_19 = new QLineEdit(Radio5);
        lineEdit_19->setObjectName(QString::fromUtf8("lineEdit_19"));
        lineEdit_19->setGeometry(QRect(520, 250, 113, 20));
        lineEdit_13 = new QLineEdit(Radio5);
        lineEdit_13->setObjectName(QString::fromUtf8("lineEdit_13"));
        lineEdit_13->setGeometry(QRect(520, 290, 113, 20));
        lineEdit_9 = new QLineEdit(Radio5);
        lineEdit_9->setObjectName(QString::fromUtf8("lineEdit_9"));
        lineEdit_9->setGeometry(QRect(520, 130, 113, 20));
        lineEdit_10 = new QLineEdit(Radio5);
        lineEdit_10->setObjectName(QString::fromUtf8("lineEdit_10"));
        lineEdit_10->setGeometry(QRect(520, 210, 113, 20));
        lineEdit_21 = new QLineEdit(Radio5);
        lineEdit_21->setObjectName(QString::fromUtf8("lineEdit_21"));
        lineEdit_21->setGeometry(QRect(520, 50, 113, 20));
        lineEdit_22 = new QLineEdit(Radio5);
        lineEdit_22->setObjectName(QString::fromUtf8("lineEdit_22"));
        lineEdit_22->setGeometry(QRect(520, 330, 113, 20));
        lineEdit_24 = new QLineEdit(Radio5);
        lineEdit_24->setObjectName(QString::fromUtf8("lineEdit_24"));
        lineEdit_24->setGeometry(QRect(520, 170, 113, 20));
        lineEdit_2 = new QLineEdit(Radio5);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(280, 330, 113, 20));
        pushButton = new QPushButton(Radio5);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(630, 430, 75, 23));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        frame = new QFrame(Radio5);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(200, 360, 281, 111));
        frame->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        label_3 = new QLabel(frame);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(30, 10, 201, 20));
        pushButton_2 = new QPushButton(frame);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(10, 80, 91, 23));
        radioButton = new QRadioButton(frame);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(100, 40, 82, 17));
        radioButton_2 = new QRadioButton(frame);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));
        radioButton_2->setGeometry(QRect(160, 40, 82, 17));
        label_4 = new QLabel(frame);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(160, 80, 101, 16));
        lineEdit_25 = new QLineEdit(frame);
        lineEdit_25->setObjectName(QString::fromUtf8("lineEdit_25"));
        lineEdit_25->setGeometry(QRect(110, 80, 51, 20));

        retranslateUi(Radio5);

        QMetaObject::connectSlotsByName(Radio5);
    } // setupUi

    void retranslateUi(QWidget *Radio5)
    {
        Radio5->setWindowTitle(QCoreApplication::translate("Radio5", "Form", nullptr));
        lineEdit->setPlaceholderText(QCoreApplication::translate("Radio5", "\331\201\330\247\331\205\333\214\331\204\333\214...", nullptr));
        lineEdit_3->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\261\331\206\332\257 \330\257\330\247\330\256\331\204 \330\247\330\252\331\210\331\205\330\250\333\214\331\204...", nullptr));
        lineEdit_4->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\264\331\205\330\247\330\261\331\207 \330\263\331\206\330\257 \330\247\330\252\331\210\331\205\330\250\333\214\331\204...", nullptr));
        lineEdit_5->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\264\331\205\330\247\330\261\331\207 \330\264\331\206\330\247\330\263\331\206\330\247\331\205\331\207...", nullptr));
        lineEdit_6->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\264\331\205\330\247\330\261\331\207 \331\205\331\210\330\250\330\247\333\214\331\204 ...", nullptr));
        lineEdit_7->setPlaceholderText(QCoreApplication::translate("Radio5", "\331\206\330\247\331\205 ...", nullptr));
        lineEdit_11->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\252\331\204\331\201\331\206 \331\205\330\255\331\204 \332\251\330\247\330\261 ...", nullptr));
        lineEdit_12->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\264\331\205\330\247\330\261\331\207 \330\264\330\247\330\263\333\214 \330\247\330\252\331\210\331\205\330\250\333\214\331\204", nullptr));
        lineEdit_14->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\252\330\247\330\261\333\214\330\256 \330\252\331\210\331\204\330\257 ...", nullptr));
        lineEdit_15->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\264\330\272\331\204 ...", nullptr));
        lineEdit_16->setPlaceholderText(QCoreApplication::translate("Radio5", "\332\251\330\257 \331\205\331\204\333\214 ...", nullptr));
        lineEdit_17->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\261\331\206\332\257 \330\247\330\252\331\210\331\205\330\250\333\214\331\204...", nullptr));
        lineEdit_18->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\250\330\261\331\206\330\257 \330\256\331\210\330\257\330\261\331\210...", nullptr));
        lineEdit_20->setPlaceholderText(QCoreApplication::translate("Radio5", "\331\206\330\247\331\205 \330\256\331\210\330\257\330\261\331\210...", nullptr));
        lineEdit_23->setPlaceholderText(QCoreApplication::translate("Radio5", "\331\202\333\214\331\205\330\252 \330\256\331\210\330\257\330\261\331\210...", nullptr));
        comboBox_2->setItemText(0, QCoreApplication::translate("Radio5", "\330\247\330\252\331\210\331\205\330\250\333\214\331\204 \330\263\331\210\330\247\330\261\333\214", nullptr));
        comboBox_2->setItemText(1, QCoreApplication::translate("Radio5", "\330\247\330\252\331\210\331\205\330\250\333\214\331\204 \330\264\330\247\330\263\333\214 \330\250\331\204\331\206\330\257", nullptr));
        comboBox_2->setItemText(2, QCoreApplication::translate("Radio5", "\330\247\330\252\331\210\331\205\330\250\333\214\331\204 \331\210\330\247\331\206\330\252", nullptr));
        comboBox_2->setItemText(3, QCoreApplication::translate("Radio5", "\330\247\330\252\331\210\331\205\330\250\333\214\331\204 \332\251\330\261\331\210\332\251", nullptr));
        comboBox_2->setItemText(4, QCoreApplication::translate("Radio5", "\330\247\330\252\331\210\331\205\330\250\333\214\331\204  \330\257\331\210 \330\257\330\261", nullptr));
        comboBox_2->setItemText(5, QString());

        label->setText(QCoreApplication::translate("Radio5", "\330\256\330\261\333\214\330\257\330\247\330\261", nullptr));
        label_2->setText(QCoreApplication::translate("Radio5", "\331\201\330\261\331\210\330\264\331\206\330\257\331\207", nullptr));
        lineEdit_8->setPlaceholderText(QCoreApplication::translate("Radio5", "\331\201\330\247\331\205\333\214\331\204\333\214...", nullptr));
        lineEdit_19->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\264\330\272\331\204 ...", nullptr));
        lineEdit_13->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\252\331\204\331\201\331\206 \331\205\330\255\331\204 \332\251\330\247\330\261 ...", nullptr));
        lineEdit_9->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\264\331\205\330\247\330\261\331\207 \331\205\331\210\330\250\330\247\333\214\331\204 ...", nullptr));
        lineEdit_10->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\264\331\205\330\247\330\261\331\207 \330\264\331\206\330\247\330\263\331\206\330\247\331\205\331\207...", nullptr));
        lineEdit_21->setPlaceholderText(QCoreApplication::translate("Radio5", "\331\206\330\247\331\205 ...", nullptr));
        lineEdit_22->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\252\330\247\330\261\333\214\330\256 \330\252\331\210\331\204\330\257 ...", nullptr));
        lineEdit_24->setPlaceholderText(QCoreApplication::translate("Radio5", "\332\251\330\257 \331\205\331\204\333\214 ...", nullptr));
        lineEdit_2->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\263\330\247\331\204 \330\252\331\210\331\204\333\214\330\257 \330\247\330\252\331\210\331\205\330\250\333\214\331\204...", nullptr));
        pushButton->setText(QCoreApplication::translate("Radio5", "\330\253\330\250\330\252 \331\202\331\210\331\204\331\206\330\247\331\205\331\207", nullptr));
        label_3->setText(QCoreApplication::translate("Radio5", "\330\242\333\214\330\247 \330\250\330\261\330\247\333\214 \330\247\330\252\331\210\331\205\330\250\333\214\331\204 \332\206\332\251 \330\257\330\261\333\214\330\247\331\201\330\252 \330\264\330\257\331\207\330\237", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Radio5", "\330\253\330\250\330\252 \330\247\330\267\331\204\330\247\330\271\330\247\330\252 \332\206\332\251", nullptr));
        radioButton->setText(QCoreApplication::translate("Radio5", "\330\256\333\214\330\261", nullptr));
        radioButton_2->setText(QCoreApplication::translate("Radio5", "\330\250\331\204\333\214", nullptr));
        label_4->setText(QCoreApplication::translate("Radio5", "\330\252\330\271\330\257\330\247\330\257 \332\206\332\251 \330\261\330\247 \331\210\330\247\330\261\330\257 \332\251\331\206\333\214\330\257", nullptr));
        lineEdit_25->setPlaceholderText(QCoreApplication::translate("Radio5", "\330\252\330\271\330\257\330\247\330\257 \332\206\332\251", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Radio5: public Ui_Radio5 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RADIO5_H
