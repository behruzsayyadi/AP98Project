#include "optionform.h"
#include "ui_optionform.h"
#include"radio5.h"

optionform::optionform(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::optionform)
{
    ui->setupUi(this);
}

optionform::~optionform()
{
    delete ui;
}

void optionform::on_pushButton_clicked()
{
    if(ui->radioButton_5->isChecked()==true){
        Radio5 *r=new Radio5;
        r->setWindowTitle("خرید و فروش اتومبیل");
        r->show();
    }



}
