#include "commonpersonpanel.h"

CommonPersonPanel::CommonPersonPanel(QObject *parent)
    : QAbstractItemModel(parent)
{
}

QVariant CommonPersonPanel::headerData(int section, Qt::Orientation orientation, int role) const
{
    // FIXME: Implement me!
}

QModelIndex CommonPersonPanel::index(int row, int column, const QModelIndex &parent) const
{
    // FIXME: Implement me!
}

QModelIndex CommonPersonPanel::parent(const QModelIndex &index) const
{
    // FIXME: Implement me!
}

int CommonPersonPanel::rowCount(const QModelIndex &parent) const
{
    if (!parent.isValid())
        return 0;

    // FIXME: Implement me!
}

int CommonPersonPanel::columnCount(const QModelIndex &parent) const
{
    if (!parent.isValid())
        return 0;

    // FIXME: Implement me!
}

QVariant CommonPersonPanel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();

    // FIXME: Implement me!
    return QVariant();
}
