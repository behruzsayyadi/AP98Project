#ifndef SABTCHEK_H
#define SABTCHEK_H

#include <QWidget>

namespace Ui {
class sabtchek;
}

class sabtchek : public QWidget
{
    Q_OBJECT

public:
    explicit sabtchek(QWidget *parent = nullptr);
    ~sabtchek();

private:
    Ui::sabtchek *ui;
};

#endif // SABTCHEK_H
