#include "personpanel.h"
#include "ui_personpanel.h"

PersonPanel::PersonPanel(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PersonPanel)
{
    ui->setupUi(this);
}

PersonPanel::~PersonPanel()
{
    delete ui;
}
