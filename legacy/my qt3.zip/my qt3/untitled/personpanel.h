#ifndef PERSONPANEL_H
#define PERSONPANEL_H

#include <QWidget>

namespace Ui {
class PersonPanel;
}

class PersonPanel : public QWidget
{
    Q_OBJECT

public:
    explicit PersonPanel(QWidget *parent = nullptr);
    ~PersonPanel();

private:
    Ui::PersonPanel *ui;
};

#endif // PERSONPANEL_H
