#include "sabtchek.h"
#include "ui_sabtchek.h"

sabtchek::sabtchek(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::sabtchek)
{
    ui->setupUi(this);
}

sabtchek::~sabtchek()
{
    delete ui;
}
