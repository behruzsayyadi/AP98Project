#include "checkinfo.h"

Checkinfo::Checkinfo()
{

}
Checkinfo::Checkinfo(QString money,QString date,QString shenase){
    this->money=money;
    this->date=date;
    this->shenase=shenase;
}
void Checkinfo::setmoney(QString money){
    this->money=money;
}
void Checkinfo:: setdate(QString date){
    this->date=date;
}
void Checkinfo:: setshenase(QString shenase){
    this->shenase=shenase;
}
