/********************************************************************************
** Form generated from reading UI file 'radio9.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RADIO9_H
#define UI_RADIO9_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Radio9
{
public:
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_8;
    QLineEdit *lineEdit_9;
    QLineEdit *lineEdit_10;
    QLineEdit *lineEdit_11;
    QLineEdit *lineEdit_12;
    QLineEdit *lineEdit_13;
    QLineEdit *lineEdit_14;
    QLineEdit *lineEdit_15;
    QLineEdit *lineEdit_16;
    QLineEdit *lineEdit_17;
    QLineEdit *lineEdit_18;
    QLineEdit *lineEdit_19;
    QLineEdit *lineEdit_20;
    QLineEdit *lineEdit_21;
    QLineEdit *lineEdit_22;
    QLineEdit *lineEdit_23;
    QLineEdit *lineEdit_24;
    QLineEdit *lineEdit_25;
    QLineEdit *lineEdit_26;
    QLineEdit *lineEdit_27;
    QLineEdit *lineEdit_28;
    QLineEdit *lineEdit_29;
    QLineEdit *lineEdit_30;
    QLineEdit *lineEdit_31;
    QLineEdit *lineEdit_32;
    QLineEdit *lineEdit_33;
    QLineEdit *lineEdit_34;
    QLineEdit *lineEdit_35;
    QLineEdit *lineEdit_36;
    QLineEdit *lineEdit_37;
    QLineEdit *lineEdit_38;
    QLineEdit *lineEdit_39;
    QLineEdit *lineEdit_40;
    QLineEdit *lineEdit_41;
    QLineEdit *lineEdit_42;
    QLineEdit *lineEdit_43;
    QLineEdit *lineEdit_44;
    QLineEdit *lineEdit_45;
    QLineEdit *lineEdit_46;
    QLineEdit *lineEdit_47;
    QLineEdit *lineEdit_48;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QWidget *Radio9)
    {
        if (Radio9->objectName().isEmpty())
            Radio9->setObjectName(QString::fromUtf8("Radio9"));
        Radio9->resize(704, 462);
        Radio9->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit = new QLineEdit(Radio9);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(70, 30, 113, 20));
        lineEdit_2 = new QLineEdit(Radio9);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(200, 30, 113, 20));
        lineEdit_3 = new QLineEdit(Radio9);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(330, 30, 113, 20));
        lineEdit_4 = new QLineEdit(Radio9);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(460, 30, 113, 20));
        lineEdit_5 = new QLineEdit(Radio9);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(70, 60, 113, 20));
        lineEdit_6 = new QLineEdit(Radio9);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(200, 60, 113, 20));
        lineEdit_7 = new QLineEdit(Radio9);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(330, 60, 113, 20));
        lineEdit_8 = new QLineEdit(Radio9);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(460, 60, 113, 20));
        lineEdit_9 = new QLineEdit(Radio9);
        lineEdit_9->setObjectName(QString::fromUtf8("lineEdit_9"));
        lineEdit_9->setGeometry(QRect(70, 90, 113, 20));
        lineEdit_10 = new QLineEdit(Radio9);
        lineEdit_10->setObjectName(QString::fromUtf8("lineEdit_10"));
        lineEdit_10->setGeometry(QRect(200, 90, 113, 20));
        lineEdit_11 = new QLineEdit(Radio9);
        lineEdit_11->setObjectName(QString::fromUtf8("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(330, 90, 113, 20));
        lineEdit_12 = new QLineEdit(Radio9);
        lineEdit_12->setObjectName(QString::fromUtf8("lineEdit_12"));
        lineEdit_12->setGeometry(QRect(460, 90, 113, 20));
        lineEdit_13 = new QLineEdit(Radio9);
        lineEdit_13->setObjectName(QString::fromUtf8("lineEdit_13"));
        lineEdit_13->setGeometry(QRect(70, 120, 113, 20));
        lineEdit_14 = new QLineEdit(Radio9);
        lineEdit_14->setObjectName(QString::fromUtf8("lineEdit_14"));
        lineEdit_14->setGeometry(QRect(200, 120, 113, 20));
        lineEdit_15 = new QLineEdit(Radio9);
        lineEdit_15->setObjectName(QString::fromUtf8("lineEdit_15"));
        lineEdit_15->setGeometry(QRect(330, 120, 113, 20));
        lineEdit_16 = new QLineEdit(Radio9);
        lineEdit_16->setObjectName(QString::fromUtf8("lineEdit_16"));
        lineEdit_16->setGeometry(QRect(460, 120, 113, 20));
        lineEdit_17 = new QLineEdit(Radio9);
        lineEdit_17->setObjectName(QString::fromUtf8("lineEdit_17"));
        lineEdit_17->setGeometry(QRect(70, 150, 113, 20));
        lineEdit_18 = new QLineEdit(Radio9);
        lineEdit_18->setObjectName(QString::fromUtf8("lineEdit_18"));
        lineEdit_18->setGeometry(QRect(200, 150, 113, 20));
        lineEdit_19 = new QLineEdit(Radio9);
        lineEdit_19->setObjectName(QString::fromUtf8("lineEdit_19"));
        lineEdit_19->setGeometry(QRect(330, 150, 113, 20));
        lineEdit_20 = new QLineEdit(Radio9);
        lineEdit_20->setObjectName(QString::fromUtf8("lineEdit_20"));
        lineEdit_20->setGeometry(QRect(460, 150, 113, 20));
        lineEdit_21 = new QLineEdit(Radio9);
        lineEdit_21->setObjectName(QString::fromUtf8("lineEdit_21"));
        lineEdit_21->setGeometry(QRect(70, 180, 113, 20));
        lineEdit_22 = new QLineEdit(Radio9);
        lineEdit_22->setObjectName(QString::fromUtf8("lineEdit_22"));
        lineEdit_22->setGeometry(QRect(200, 180, 113, 20));
        lineEdit_23 = new QLineEdit(Radio9);
        lineEdit_23->setObjectName(QString::fromUtf8("lineEdit_23"));
        lineEdit_23->setGeometry(QRect(330, 180, 113, 20));
        lineEdit_24 = new QLineEdit(Radio9);
        lineEdit_24->setObjectName(QString::fromUtf8("lineEdit_24"));
        lineEdit_24->setGeometry(QRect(460, 180, 113, 20));
        lineEdit_25 = new QLineEdit(Radio9);
        lineEdit_25->setObjectName(QString::fromUtf8("lineEdit_25"));
        lineEdit_25->setGeometry(QRect(70, 210, 113, 20));
        lineEdit_26 = new QLineEdit(Radio9);
        lineEdit_26->setObjectName(QString::fromUtf8("lineEdit_26"));
        lineEdit_26->setGeometry(QRect(200, 210, 113, 20));
        lineEdit_27 = new QLineEdit(Radio9);
        lineEdit_27->setObjectName(QString::fromUtf8("lineEdit_27"));
        lineEdit_27->setGeometry(QRect(330, 210, 113, 20));
        lineEdit_28 = new QLineEdit(Radio9);
        lineEdit_28->setObjectName(QString::fromUtf8("lineEdit_28"));
        lineEdit_28->setGeometry(QRect(460, 210, 113, 20));
        lineEdit_29 = new QLineEdit(Radio9);
        lineEdit_29->setObjectName(QString::fromUtf8("lineEdit_29"));
        lineEdit_29->setGeometry(QRect(70, 240, 113, 20));
        lineEdit_30 = new QLineEdit(Radio9);
        lineEdit_30->setObjectName(QString::fromUtf8("lineEdit_30"));
        lineEdit_30->setGeometry(QRect(200, 240, 113, 20));
        lineEdit_31 = new QLineEdit(Radio9);
        lineEdit_31->setObjectName(QString::fromUtf8("lineEdit_31"));
        lineEdit_31->setGeometry(QRect(330, 240, 113, 20));
        lineEdit_32 = new QLineEdit(Radio9);
        lineEdit_32->setObjectName(QString::fromUtf8("lineEdit_32"));
        lineEdit_32->setGeometry(QRect(460, 240, 113, 20));
        lineEdit_33 = new QLineEdit(Radio9);
        lineEdit_33->setObjectName(QString::fromUtf8("lineEdit_33"));
        lineEdit_33->setGeometry(QRect(70, 270, 113, 20));
        lineEdit_34 = new QLineEdit(Radio9);
        lineEdit_34->setObjectName(QString::fromUtf8("lineEdit_34"));
        lineEdit_34->setGeometry(QRect(200, 270, 113, 20));
        lineEdit_35 = new QLineEdit(Radio9);
        lineEdit_35->setObjectName(QString::fromUtf8("lineEdit_35"));
        lineEdit_35->setGeometry(QRect(330, 270, 113, 20));
        lineEdit_36 = new QLineEdit(Radio9);
        lineEdit_36->setObjectName(QString::fromUtf8("lineEdit_36"));
        lineEdit_36->setGeometry(QRect(460, 270, 113, 20));
        lineEdit_37 = new QLineEdit(Radio9);
        lineEdit_37->setObjectName(QString::fromUtf8("lineEdit_37"));
        lineEdit_37->setGeometry(QRect(70, 300, 113, 20));
        lineEdit_38 = new QLineEdit(Radio9);
        lineEdit_38->setObjectName(QString::fromUtf8("lineEdit_38"));
        lineEdit_38->setGeometry(QRect(200, 300, 113, 20));
        lineEdit_39 = new QLineEdit(Radio9);
        lineEdit_39->setObjectName(QString::fromUtf8("lineEdit_39"));
        lineEdit_39->setGeometry(QRect(330, 300, 113, 20));
        lineEdit_40 = new QLineEdit(Radio9);
        lineEdit_40->setObjectName(QString::fromUtf8("lineEdit_40"));
        lineEdit_40->setGeometry(QRect(460, 300, 113, 20));
        lineEdit_41 = new QLineEdit(Radio9);
        lineEdit_41->setObjectName(QString::fromUtf8("lineEdit_41"));
        lineEdit_41->setGeometry(QRect(70, 330, 113, 20));
        lineEdit_42 = new QLineEdit(Radio9);
        lineEdit_42->setObjectName(QString::fromUtf8("lineEdit_42"));
        lineEdit_42->setGeometry(QRect(200, 330, 113, 20));
        lineEdit_43 = new QLineEdit(Radio9);
        lineEdit_43->setObjectName(QString::fromUtf8("lineEdit_43"));
        lineEdit_43->setGeometry(QRect(330, 330, 113, 20));
        lineEdit_44 = new QLineEdit(Radio9);
        lineEdit_44->setObjectName(QString::fromUtf8("lineEdit_44"));
        lineEdit_44->setGeometry(QRect(460, 330, 113, 20));
        lineEdit_45 = new QLineEdit(Radio9);
        lineEdit_45->setObjectName(QString::fromUtf8("lineEdit_45"));
        lineEdit_45->setGeometry(QRect(70, 360, 113, 20));
        lineEdit_46 = new QLineEdit(Radio9);
        lineEdit_46->setObjectName(QString::fromUtf8("lineEdit_46"));
        lineEdit_46->setGeometry(QRect(200, 360, 113, 20));
        lineEdit_47 = new QLineEdit(Radio9);
        lineEdit_47->setObjectName(QString::fromUtf8("lineEdit_47"));
        lineEdit_47->setGeometry(QRect(330, 360, 113, 20));
        lineEdit_48 = new QLineEdit(Radio9);
        lineEdit_48->setObjectName(QString::fromUtf8("lineEdit_48"));
        lineEdit_48->setGeometry(QRect(460, 360, 113, 20));
        label = new QLabel(Radio9);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(90, 10, 61, 16));
        label_2 = new QLabel(Radio9);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(230, 10, 61, 16));
        label_3 = new QLabel(Radio9);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(350, 10, 81, 16));
        label_4 = new QLabel(Radio9);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(480, 10, 71, 16));
        pushButton = new QPushButton(Radio9);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(584, 420, 91, 23));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        pushButton_2 = new QPushButton(Radio9);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(20, 420, 91, 23));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));

        retranslateUi(Radio9);

        QMetaObject::connectSlotsByName(Radio9);
    } // setupUi

    void retranslateUi(QWidget *Radio9)
    {
        Radio9->setWindowTitle(QCoreApplication::translate("Radio9", "Form", nullptr));
        label->setText(QCoreApplication::translate("Radio9", "\331\206\330\247\331\205 \330\247\330\252\331\210\331\205\330\250\333\214\331\204", nullptr));
        label_2->setText(QCoreApplication::translate("Radio9", "\330\261\331\206\332\257 \330\247\330\252\331\210\331\205\330\250\333\214\331\204", nullptr));
        label_3->setText(QCoreApplication::translate("Radio9", "\330\263\330\247\331\204 \330\252\331\210\331\204\333\214\330\257 \330\247\330\252\331\210\331\205\330\250\333\214\331\204", nullptr));
        label_4->setText(QCoreApplication::translate("Radio9", "\331\202\333\214\331\205\330\252 \330\247\330\252\331\210\331\205\330\250\333\214\331\204", nullptr));
        pushButton->setText(QCoreApplication::translate("Radio9", "\331\206\331\205\330\247\333\214\330\264 \330\247\330\267\331\204\330\247\330\271\330\247\330\252", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Radio9", "\330\253\330\250\330\252 \330\252\330\272\333\214\330\261\330\247\330\252", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Radio9: public Ui_Radio9 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RADIO9_H
