#include "radio5.h"
#include "ui_radio5.h"
#include"sabtchek.h"
#include<QFile>
#include<QTextStream>
#include<QString>
#include<checkinfo.h>
#include<QMessageBox>
#include<customer.h>
#include<seller.h>

Radio5::Radio5(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Radio5)
{
    ui->setupUi(this);
}

Radio5::~Radio5()
{
    delete ui;
}

void Radio5::on_pushButton_2_clicked()
{
    if(ui->radioButton_2->isChecked()==true){
        sabtchek*s=new sabtchek;
        s->setWindowTitle("ثبت اطلاعات چک");
        s->show();
    }
}

void Radio5::on_pushButton_clicked()
{

Customer cu;
Seller se;
////////////////////////////////خریدار
se.setname(ui->lineEdit_21->text());
se.setfamily(ui->lineEdit_8->text());
se.setmobile(ui->lineEdit_9->text());
se.setkodemeli(ui->label_19->text());
se.sethomareshenas(ui->lineEdit_10->text());
se.settelephon(ui->lineEdit_13->text());
se.setbirhtday(ui->lineEdit_15->text());
se.setaddress(ui->lineEdit_27->text());
////////////////////////////////////خریدار


//////////////////////////////////////فروشنده
se.setname(ui->lineEdit_32->text());
se.setfamily(ui->lineEdit_25->text());
se.setmobile(ui->lineEdit_29->text());
se.setkodemeli(ui->label_22->text());
se.sethomareshenas(ui->lineEdit_30->text());
se.settelephon(ui->lineEdit_24->text());
se.setbirhtday(ui->lineEdit_31->text());
se.setaddress(ui->lineEdit_28->text());
/////////////////////////////////////////فروشنده









//////////////////////////////////////////////////////////////چک های دریافتی
int number=ui->lineEdit_33->text().toUInt();
Checkinfo ch[10];
QFile myfile("C:\\Users\\user\\Desktop\\allFile\\newChek.txt");
if(!myfile.open(QFile::ReadOnly|QFile::Text)){

}

else{
QTextStream in(&myfile);
for(int i=0;i<number;i++){
    ch[i].setmoney(in.readLine());
    ch[i].setdate(in.readLine());
    ch[i].setshenase(in.readLine());

}

}

myfile.close();
/////////////////////////////////////////////////////////////////////چک های دریافتی
QMessageBox msg;
msg.setWindowTitle("ثبت");
msg.setText("با موفقیت ثبت شد");
msg.exec();

}
