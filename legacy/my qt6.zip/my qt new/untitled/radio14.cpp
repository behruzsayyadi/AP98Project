#include "radio14.h"
#include "ui_radio14.h"
#include<QFile>
#include<QTextStream>
#include<QString>
#include"autogallery.h"
Radio14::Radio14(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Radio14)
{
    ui->setupUi(this);
}

Radio14::~Radio14()
{
    delete ui;
}

void Radio14::on_pushButton_clicked()
{
    AutoGallery au[10];
    QFile myfile("C:\\Users\\user\\Desktop\\allFile\\allAutoGallery.txt");
    if(!myfile.open(QFile::ReadOnly|QFile::Text)){

    }

    else{
        QTextStream in(&myfile);
        ui->lineEdit->setText(in.readLine());
        ui->lineEdit_2->setText(in.readLine());
        ui->lineEdit_3->setText(in.readLine());
        ui->lineEdit_4->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_6->setText(in.readLine());
        ui->lineEdit_8->setText(in.readLine());
        ui->lineEdit_7->setText(in.readLine());
        ui->lineEdit_5->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_12->setText(in.readLine());
        ui->lineEdit_9->setText(in.readLine());
        ui->lineEdit_11->setText(in.readLine());
        ui->lineEdit_10->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_13->setText(in.readLine());
        ui->lineEdit_16->setText(in.readLine());
        ui->lineEdit_15->setText(in.readLine());
        ui->lineEdit_14->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_19->setText(in.readLine());
        ui->lineEdit_17->setText(in.readLine());
        ui->lineEdit_18->setText(in.readLine());
        ui->lineEdit_20->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_23->setText(in.readLine());
        ui->lineEdit_24->setText(in.readLine());
        ui->lineEdit_22->setText(in.readLine());
        ui->lineEdit_21->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_28->setText(in.readLine());
        ui->lineEdit_25->setText(in.readLine());
        ui->lineEdit_26->setText(in.readLine());
        ui->lineEdit_27->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_29->setText(in.readLine());
        ui->lineEdit_32->setText(in.readLine());
        ui->lineEdit_31->setText(in.readLine());
        ui->lineEdit_30->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_36->setText(in.readLine());
        ui->lineEdit_33->setText(in.readLine());
        ui->lineEdit_35->setText(in.readLine());
        ui->lineEdit_34->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_37->setText(in.readLine());
        ui->lineEdit_38->setText(in.readLine());
        ui->lineEdit_39->setText(in.readLine());
        ui->lineEdit_40->setText(in.readLine());



    }

}

void Radio14::on_pushButton_2_clicked()
{
    QFile myfile("C:\\Users\\user\\Desktop\\allFile\\allAutoGallery.txt");
    if(!myfile.open(QFile::WriteOnly|QFile::Text)){

    }
    else{
    QTextStream out(&myfile);
    out<<ui->lineEdit->text()+"\n";
    out<<ui->lineEdit_2->text()+"\n";
    out<<ui->lineEdit_3->text()+"\n";
    out<<ui->lineEdit_4->text()+"\n";
    ////////////////////////////////////////
    out<<ui->lineEdit_6->text()+"\n";
    out<<ui->lineEdit_8->text()+"\n";
    out<<ui->lineEdit_7->text()+"\n";
    out<<ui->lineEdit_5->text()+"\n";


    out<<ui->lineEdit_12->text()+"\n";
    out<<ui->lineEdit_9->text()+"\n";
    out<<ui->lineEdit_11->text()+"\n";
    out<<ui->lineEdit_10->text()+"\n";
    ////////////////////////////////////////
    out<<ui->lineEdit_13->text()+"\n";
    out<<ui->lineEdit_16->text()+"\n";
    out<<ui->lineEdit_15->text()+"\n";
    out<<ui->lineEdit_14->text()+"\n";


    out<<ui->lineEdit_19->text()+"\n";
    out<<ui->lineEdit_17->text()+"\n";
    out<<ui->lineEdit_18->text()+"\n";
    out<<ui->lineEdit_20->text()+"\n";
    ////////////////////////////////////////
    out<<ui->lineEdit_23->text()+"\n";
    out<<ui->lineEdit_24->text()+"\n";
    out<<ui->lineEdit_22->text()+"\n";
    out<<ui->lineEdit_21->text()+"\n";

    out<<ui->lineEdit_28->text()+"\n";
    out<<ui->lineEdit_25->text()+"\n";
    out<<ui->lineEdit_26->text()+"\n";
    out<<ui->lineEdit_27->text()+"\n";
    ////////////////////////////////////////
    out<<ui->lineEdit_29->text()+"\n";
    out<<ui->lineEdit_32->text()+"\n";
    out<<ui->lineEdit_31->text()+"\n";
    out<<ui->lineEdit_30->text()+"\n";

    out<<ui->lineEdit_36->text()+"\n";
    out<<ui->lineEdit_33->text()+"\n";
    out<<ui->lineEdit_35->text()+"\n";
    out<<ui->lineEdit_34->text()+"\n";
    ////////////////////////////////////////
    out<<ui->lineEdit_37->text()+"\n";
    out<<ui->lineEdit_38->text()+"\n";
    out<<ui->lineEdit_39->text()+"\n";
    out<<ui->lineEdit_40->text()+"\n";
    myfile.flush();
    myfile.close();
}


}
