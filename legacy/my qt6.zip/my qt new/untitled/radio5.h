#ifndef RADIO5_H
#define RADIO5_H

#include <QWidget>

namespace Ui {
class Radio5;
}

class Radio5 : public QWidget
{
    Q_OBJECT

public:
    explicit Radio5(QWidget *parent = nullptr);
    ~Radio5();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::Radio5 *ui;
};

#endif // RADIO5_H
