#ifndef RADIO4_H
#define RADIO4_H

#include <QWidget>

namespace Ui {
class Radio4;
}

class Radio4 : public QWidget
{
    Q_OBJECT

public:
    explicit Radio4(QWidget *parent = nullptr);
    ~Radio4();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Radio4 *ui;
};

#endif // RADIO4_H
