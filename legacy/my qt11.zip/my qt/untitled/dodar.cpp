#include "dodar.h"

Dodar::Dodar()
{

}
double Dodar::getpoorsant(double allmoney){
    return (0.005*allmoney);
}
