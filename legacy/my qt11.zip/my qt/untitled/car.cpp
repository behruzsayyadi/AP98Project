#include "car.h"

Car::Car()
{

}


void Car:: setname(QString name){
    this->name=name;
}
void Car::setrang(QString rang){
    this->rang=rang;
}
void Car::setInrang(QString rang_dakhel){
    this->range_dakhel=rang_dakhel;
}
void Car::setshasi(QString shasi){
    this->shasi=shasi;
}
void Car::setsanad(QString sanad){
    this->sanad=sanad;
}
void Car::setbrand(QString brand){
    this->brand=brand;
}
void Car::setgheymat(QString gheymat){
    this->gheymat=gheymat;
}
void Car::setsal(QString sal){
    this->sale_tolid=sal;
}


QString Car::getname(){
    return name;
}
QString Car::getrang(){
    return  rang;
}
QString Car::getInrang(){
    return  range_dakhel;
}
QString Car::getshasi(){
    return shasi;
}
QString Car::getsanad(){
    return sanad;
}
QString Car::getbrand(){
    return  brand;
}
QString Car::getgheymat(){
    return  gheymat;
}
QString Car::getsal(){
    return  sale_tolid;
}
