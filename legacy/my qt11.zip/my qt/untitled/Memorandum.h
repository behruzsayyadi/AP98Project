#ifndef MEMORANDUM_H
#define MEMORANDUM_H
#include"customer.h"
#include"seller.h"
#include"car.h"
#include"dodar.h"
#include"shasiboland.h"
#include"savari.h"
#include"korook.h"
#include"vanetcar.h"
#endif // MEMORANDUM_H
#include<QFile>
#include<QString>
#include<QTextStream>


void memorandum(Seller se,Customer cu,Car ca,int year,int month,int day,int hour,int minuts,int numberchek){
QFile myfile("allFile\\memorandum\\"+QString::number(year)+QString::number(month) +".txt");
myfile.open(QIODevice::Append);
QTextStream out(&myfile);
out<<"seller name:"+cu.getname()+"\n";
out<<"seller family:"+cu.getfamily()+"\n";
out<<"seller identity code1:"+cu.getkodemeli()+"\n";
out<<"seller identity code2:"+cu.gethomareshenas()+"\n";
out<<"seller mobile:"+cu.getmobile()+"\n";
out<<"seller telephon:"+cu.gettelephon()+"\n";
out<<"seller birthday:"+cu.getbirhtday()+"\n";
out<<"seller address:"+cu.getaddress()+"\n";

out<<"customer name:"+se.getname()+"\n";
out<<"customer family:"+se.getfamily()+"\n";
out<<"customer identity code1:"+se.getkodemeli()+"\n";
out<<"customer identity code2:"+se.gethomareshenas()+"\n";
out<<"customer mobile:"+se.getmobile()+"\n";
out<<"customer telephon:"+se.gettelephon()+"\n";
out<<"customer bithday:"+se.getbirhtday()+"\n";
out<<"customer address:"+se.getaddress()+"\n";

out<<"car brand:"+ca.getbrand()+"\n";
out<<"car name:"+ca.getname()+"\n";
out<<"car color:"+ca.getrang()+"\n";
out<<"car inside color:"+ca.getInrang()+"\n";
out<<"car birthday:"+ca.getsal()+"\n";
out<<"car price:"+ca.getgheymat()+"\n";
out<<"car shasi number:"+ca.getshasi()+"\n";
out<<"car sanad number:"+ca.getsanad()+"\n";
QString date=QString::number(day)+"/"+QString::number(month)+"/"+QString::number(year);
out<<"memorandum date:"+date+"\n";
QString time=QString::number(hour)+":"+QString::number(minuts);
out<<"memorandum time:"+time+"\n";

out<<"Check Info:\n";

QFile myfile2("allFile\\newChek.txt");
myfile2.open(QFile::ReadOnly|QFile::Text);
QTextStream in(&myfile2);
for(int i=0;i<numberchek;i++){
    QString money=in.readLine();
    QString date=in.readLine();
    QString shenase=in.readLine();
    out<<"Check price:"+money+"\n";
    out<<"date:"+date+"\n";
    out<<"shenase number:"+shenase+"\n";
}

out<<"******************************************************\n";


myfile2.close();

myfile.flush();
myfile.close();

}
