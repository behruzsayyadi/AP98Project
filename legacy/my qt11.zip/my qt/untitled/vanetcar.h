#ifndef VANETCAR_H
#define VANETCAR_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include"car.h"

class VanetCar:public Car
{
private:
    double poorsant;
public:
    VanetCar();
     double getpoorsant(double allmoney);
};

#endif // VANETCAR_H
