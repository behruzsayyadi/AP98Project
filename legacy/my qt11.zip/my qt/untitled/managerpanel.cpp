#include "managerpanel.h"
#include "ui_managerpanel.h"
#include"optionform.h"
#include"qapplication.h"
#include<QFile>
#include<QString>
#include<QTextStream>
#include<QMessageBox>

ManagerPanel::ManagerPanel(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ManagerPanel)
{
    ui->setupUi(this);
}

ManagerPanel::~ManagerPanel()
{
    delete ui;
}

void ManagerPanel::on_pushButton_clicked()
{
    QString username="";
    QString password="";
    QFile myfile("allFile\\managerinfo.txt");
    if(!myfile.open(QFile::ReadOnly|QFile::Text)){


    }
    else{
        QTextStream in(&myfile);
        m.setname(in.readLine());
        m.setfamily(in.readLine());
        m.username=in.readLine();
        m.password=in.readLine();


    }
    if( ui->lineEdit_3->text()==m.username && ui->lineEdit_4->text()==m.password&&ui->lineEdit_6->text()==m.getname()&&ui->lineEdit_5->text()==m.getfamily()){


    ui->lineEdit_3->setText("");
    ui->lineEdit_4->setText("");
    ui->lineEdit_5->setText("");
    ui->lineEdit_6->setText("");
    optionform *option=new optionform;
    option->setWindowTitle("Mr.Borjegani");
    option->show();
    }
myfile.close();
}
