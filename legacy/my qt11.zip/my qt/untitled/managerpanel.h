#ifndef MANAGERPANEL_H
#define MANAGERPANEL_H

#include <QWidget>
#include"manager.h"
namespace Ui {
class ManagerPanel;
}

class ManagerPanel : public QWidget
{
    Q_OBJECT

public:
    Manager m;
    explicit ManagerPanel(QWidget *parent = nullptr);
    ~ManagerPanel();

private slots:
    void on_pushButton_clicked();

private:
    Ui::ManagerPanel *ui;
};

#endif // MANAGERPANEL_H
