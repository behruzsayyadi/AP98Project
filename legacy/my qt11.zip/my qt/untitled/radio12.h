#ifndef RADIO12_H
#define RADIO12_H

#include <QWidget>
#include"manager.h"

namespace Ui {
class Radio12;
}

class Radio12 : public QWidget
{
    Q_OBJECT

public:
    Manager m;
    explicit Radio12(QWidget *parent = nullptr);
    ~Radio12();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Radio12 *ui;
};

#endif // RADIO12_H
