#ifndef CAR_H
#define CAR_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>

class Car
{
protected:
    QString name;
    QString rang;
    QString range_dakhel;
    QString shasi;
    QString sanad;
    QString brand;
    QString gheymat;
    QString sale_tolid;
    double poorsant;
public:
    Car();
    void setname(QString name);
    void setrang(QString rang);
    void setInrang(QString rang_dakhel);
    void setshasi(QString shasi);
    void setsanad(QString sanad);
    void setbrand(QString brand);
    void setgheymat(QString gheymat);
    void setsal(QString sal);


    QString getname();
    QString getrang();
    QString getInrang();
    QString getshasi();
    QString getsanad();
    QString getbrand();
    QString getgheymat();
    QString getsal();
     double getpoorsant();
};

#endif // CAR_H
