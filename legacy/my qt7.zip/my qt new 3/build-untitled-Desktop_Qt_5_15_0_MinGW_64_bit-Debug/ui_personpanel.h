/********************************************************************************
** Form generated from reading UI file 'personpanel.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PERSONPANEL_H
#define UI_PERSONPANEL_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PersonPanel
{
public:
    QLineEdit *lineEdit_44;
    QLineEdit *lineEdit_30;
    QLineEdit *lineEdit_39;
    QLineEdit *lineEdit_42;
    QLineEdit *lineEdit_40;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_28;
    QLineEdit *lineEdit_35;
    QLineEdit *lineEdit_3;
    QLabel *label_4;
    QLineEdit *lineEdit_17;
    QLineEdit *lineEdit_6;
    QLabel *label_3;
    QLabel *label_2;
    QLabel *label;
    QPushButton *pushButton;
    QLineEdit *lineEdit_19;
    QLineEdit *lineEdit_34;
    QLineEdit *lineEdit_27;
    QLineEdit *lineEdit_48;
    QLineEdit *lineEdit_16;
    QLineEdit *lineEdit_8;
    QLineEdit *lineEdit_31;
    QLineEdit *lineEdit_36;
    QLineEdit *lineEdit_43;
    QLineEdit *lineEdit_46;
    QLineEdit *lineEdit_32;
    QLineEdit *lineEdit_26;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_24;
    QLineEdit *lineEdit_22;
    QLineEdit *lineEdit_18;
    QLineEdit *lineEdit_29;
    QLineEdit *lineEdit_13;
    QLineEdit *lineEdit_38;
    QLineEdit *lineEdit_45;
    QLineEdit *lineEdit_25;
    QLineEdit *lineEdit_12;
    QLineEdit *lineEdit_14;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_21;
    QLineEdit *lineEdit_11;
    QLineEdit *lineEdit_9;
    QLineEdit *lineEdit_20;
    QLineEdit *lineEdit_41;
    QLineEdit *lineEdit_23;
    QLineEdit *lineEdit_33;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_47;
    QLineEdit *lineEdit_37;
    QLineEdit *lineEdit_15;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_10;
    QLabel *label_5;
    QLabel *label_6;

    void setupUi(QWidget *PersonPanel)
    {
        if (PersonPanel->objectName().isEmpty())
            PersonPanel->setObjectName(QString::fromUtf8("PersonPanel"));
        PersonPanel->resize(755, 488);
        PersonPanel->setMinimumSize(QSize(755, 488));
        PersonPanel->setMaximumSize(QSize(755, 488));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../\330\256\330\261\333\214\330\257+\330\250\331\206\330\2621.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        PersonPanel->setWindowIcon(icon);
        PersonPanel->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);"));
        lineEdit_44 = new QLineEdit(PersonPanel);
        lineEdit_44->setObjectName(QString::fromUtf8("lineEdit_44"));
        lineEdit_44->setGeometry(QRect(410, 340, 113, 20));
        lineEdit_44->setReadOnly(true);
        lineEdit_30 = new QLineEdit(PersonPanel);
        lineEdit_30->setObjectName(QString::fromUtf8("lineEdit_30"));
        lineEdit_30->setGeometry(QRect(150, 250, 113, 20));
        lineEdit_30->setReadOnly(true);
        lineEdit_39 = new QLineEdit(PersonPanel);
        lineEdit_39->setObjectName(QString::fromUtf8("lineEdit_39"));
        lineEdit_39->setGeometry(QRect(280, 310, 113, 20));
        lineEdit_39->setReadOnly(true);
        lineEdit_42 = new QLineEdit(PersonPanel);
        lineEdit_42->setObjectName(QString::fromUtf8("lineEdit_42"));
        lineEdit_42->setGeometry(QRect(150, 340, 113, 20));
        lineEdit_42->setReadOnly(true);
        lineEdit_40 = new QLineEdit(PersonPanel);
        lineEdit_40->setObjectName(QString::fromUtf8("lineEdit_40"));
        lineEdit_40->setGeometry(QRect(410, 310, 113, 20));
        lineEdit_40->setReadOnly(true);
        lineEdit_5 = new QLineEdit(PersonPanel);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(20, 70, 113, 20));
        lineEdit_5->setReadOnly(true);
        lineEdit_28 = new QLineEdit(PersonPanel);
        lineEdit_28->setObjectName(QString::fromUtf8("lineEdit_28"));
        lineEdit_28->setGeometry(QRect(410, 220, 113, 20));
        lineEdit_28->setReadOnly(true);
        lineEdit_35 = new QLineEdit(PersonPanel);
        lineEdit_35->setObjectName(QString::fromUtf8("lineEdit_35"));
        lineEdit_35->setGeometry(QRect(280, 280, 113, 20));
        lineEdit_35->setReadOnly(true);
        lineEdit_3 = new QLineEdit(PersonPanel);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(280, 40, 113, 20));
        lineEdit_3->setReadOnly(true);
        label_4 = new QLabel(PersonPanel);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(430, 20, 71, 16));
        label_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_17 = new QLineEdit(PersonPanel);
        lineEdit_17->setObjectName(QString::fromUtf8("lineEdit_17"));
        lineEdit_17->setGeometry(QRect(20, 160, 113, 20));
        lineEdit_17->setReadOnly(true);
        lineEdit_6 = new QLineEdit(PersonPanel);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(150, 70, 113, 20));
        lineEdit_6->setReadOnly(true);
        label_3 = new QLabel(PersonPanel);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(300, 20, 81, 16));
        label_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_2 = new QLabel(PersonPanel);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(180, 20, 61, 16));
        label_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label = new QLabel(PersonPanel);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 20, 61, 16));
        label->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton = new QPushButton(PersonPanel);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(660, 390, 91, 101));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        lineEdit_19 = new QLineEdit(PersonPanel);
        lineEdit_19->setObjectName(QString::fromUtf8("lineEdit_19"));
        lineEdit_19->setGeometry(QRect(280, 160, 113, 20));
        lineEdit_19->setReadOnly(true);
        lineEdit_34 = new QLineEdit(PersonPanel);
        lineEdit_34->setObjectName(QString::fromUtf8("lineEdit_34"));
        lineEdit_34->setGeometry(QRect(150, 280, 113, 20));
        lineEdit_34->setReadOnly(true);
        lineEdit_27 = new QLineEdit(PersonPanel);
        lineEdit_27->setObjectName(QString::fromUtf8("lineEdit_27"));
        lineEdit_27->setGeometry(QRect(280, 220, 113, 20));
        lineEdit_27->setReadOnly(true);
        lineEdit_48 = new QLineEdit(PersonPanel);
        lineEdit_48->setObjectName(QString::fromUtf8("lineEdit_48"));
        lineEdit_48->setGeometry(QRect(410, 370, 113, 20));
        lineEdit_48->setReadOnly(true);
        lineEdit_16 = new QLineEdit(PersonPanel);
        lineEdit_16->setObjectName(QString::fromUtf8("lineEdit_16"));
        lineEdit_16->setGeometry(QRect(410, 130, 113, 20));
        lineEdit_16->setReadOnly(true);
        lineEdit_8 = new QLineEdit(PersonPanel);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(410, 70, 113, 20));
        lineEdit_8->setReadOnly(true);
        lineEdit_31 = new QLineEdit(PersonPanel);
        lineEdit_31->setObjectName(QString::fromUtf8("lineEdit_31"));
        lineEdit_31->setGeometry(QRect(280, 250, 113, 20));
        lineEdit_31->setReadOnly(true);
        lineEdit_36 = new QLineEdit(PersonPanel);
        lineEdit_36->setObjectName(QString::fromUtf8("lineEdit_36"));
        lineEdit_36->setGeometry(QRect(410, 280, 113, 20));
        lineEdit_36->setReadOnly(true);
        lineEdit_43 = new QLineEdit(PersonPanel);
        lineEdit_43->setObjectName(QString::fromUtf8("lineEdit_43"));
        lineEdit_43->setGeometry(QRect(280, 340, 113, 20));
        lineEdit_43->setReadOnly(true);
        lineEdit_46 = new QLineEdit(PersonPanel);
        lineEdit_46->setObjectName(QString::fromUtf8("lineEdit_46"));
        lineEdit_46->setGeometry(QRect(150, 370, 113, 20));
        lineEdit_46->setReadOnly(true);
        lineEdit_32 = new QLineEdit(PersonPanel);
        lineEdit_32->setObjectName(QString::fromUtf8("lineEdit_32"));
        lineEdit_32->setGeometry(QRect(410, 250, 113, 20));
        lineEdit_32->setReadOnly(true);
        lineEdit_26 = new QLineEdit(PersonPanel);
        lineEdit_26->setObjectName(QString::fromUtf8("lineEdit_26"));
        lineEdit_26->setGeometry(QRect(150, 220, 113, 20));
        lineEdit_26->setReadOnly(true);
        lineEdit = new QLineEdit(PersonPanel);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(20, 40, 113, 20));
        lineEdit->setReadOnly(true);
        lineEdit_24 = new QLineEdit(PersonPanel);
        lineEdit_24->setObjectName(QString::fromUtf8("lineEdit_24"));
        lineEdit_24->setGeometry(QRect(410, 190, 113, 20));
        lineEdit_24->setReadOnly(true);
        lineEdit_22 = new QLineEdit(PersonPanel);
        lineEdit_22->setObjectName(QString::fromUtf8("lineEdit_22"));
        lineEdit_22->setGeometry(QRect(150, 190, 113, 20));
        lineEdit_22->setReadOnly(true);
        lineEdit_18 = new QLineEdit(PersonPanel);
        lineEdit_18->setObjectName(QString::fromUtf8("lineEdit_18"));
        lineEdit_18->setGeometry(QRect(150, 160, 113, 20));
        lineEdit_18->setReadOnly(true);
        lineEdit_29 = new QLineEdit(PersonPanel);
        lineEdit_29->setObjectName(QString::fromUtf8("lineEdit_29"));
        lineEdit_29->setGeometry(QRect(20, 250, 113, 20));
        lineEdit_29->setReadOnly(true);
        lineEdit_13 = new QLineEdit(PersonPanel);
        lineEdit_13->setObjectName(QString::fromUtf8("lineEdit_13"));
        lineEdit_13->setGeometry(QRect(20, 130, 113, 20));
        lineEdit_13->setReadOnly(true);
        lineEdit_38 = new QLineEdit(PersonPanel);
        lineEdit_38->setObjectName(QString::fromUtf8("lineEdit_38"));
        lineEdit_38->setGeometry(QRect(150, 310, 113, 20));
        lineEdit_38->setReadOnly(true);
        lineEdit_45 = new QLineEdit(PersonPanel);
        lineEdit_45->setObjectName(QString::fromUtf8("lineEdit_45"));
        lineEdit_45->setGeometry(QRect(20, 370, 113, 20));
        lineEdit_45->setReadOnly(true);
        lineEdit_25 = new QLineEdit(PersonPanel);
        lineEdit_25->setObjectName(QString::fromUtf8("lineEdit_25"));
        lineEdit_25->setGeometry(QRect(20, 220, 113, 20));
        lineEdit_25->setReadOnly(true);
        lineEdit_12 = new QLineEdit(PersonPanel);
        lineEdit_12->setObjectName(QString::fromUtf8("lineEdit_12"));
        lineEdit_12->setGeometry(QRect(410, 100, 113, 20));
        lineEdit_12->setReadOnly(true);
        lineEdit_14 = new QLineEdit(PersonPanel);
        lineEdit_14->setObjectName(QString::fromUtf8("lineEdit_14"));
        lineEdit_14->setGeometry(QRect(150, 130, 113, 20));
        lineEdit_14->setReadOnly(true);
        lineEdit_4 = new QLineEdit(PersonPanel);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(410, 40, 113, 20));
        lineEdit_4->setReadOnly(true);
        lineEdit_21 = new QLineEdit(PersonPanel);
        lineEdit_21->setObjectName(QString::fromUtf8("lineEdit_21"));
        lineEdit_21->setGeometry(QRect(20, 190, 113, 20));
        lineEdit_21->setReadOnly(true);
        lineEdit_11 = new QLineEdit(PersonPanel);
        lineEdit_11->setObjectName(QString::fromUtf8("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(280, 100, 113, 20));
        lineEdit_11->setReadOnly(true);
        lineEdit_9 = new QLineEdit(PersonPanel);
        lineEdit_9->setObjectName(QString::fromUtf8("lineEdit_9"));
        lineEdit_9->setGeometry(QRect(20, 100, 113, 20));
        lineEdit_9->setReadOnly(true);
        lineEdit_20 = new QLineEdit(PersonPanel);
        lineEdit_20->setObjectName(QString::fromUtf8("lineEdit_20"));
        lineEdit_20->setGeometry(QRect(410, 160, 113, 20));
        lineEdit_20->setReadOnly(true);
        lineEdit_41 = new QLineEdit(PersonPanel);
        lineEdit_41->setObjectName(QString::fromUtf8("lineEdit_41"));
        lineEdit_41->setGeometry(QRect(20, 340, 113, 20));
        lineEdit_41->setReadOnly(true);
        lineEdit_23 = new QLineEdit(PersonPanel);
        lineEdit_23->setObjectName(QString::fromUtf8("lineEdit_23"));
        lineEdit_23->setGeometry(QRect(280, 190, 113, 20));
        lineEdit_23->setReadOnly(true);
        lineEdit_33 = new QLineEdit(PersonPanel);
        lineEdit_33->setObjectName(QString::fromUtf8("lineEdit_33"));
        lineEdit_33->setGeometry(QRect(20, 280, 113, 20));
        lineEdit_33->setReadOnly(true);
        lineEdit_7 = new QLineEdit(PersonPanel);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(280, 70, 113, 20));
        lineEdit_7->setReadOnly(true);
        lineEdit_47 = new QLineEdit(PersonPanel);
        lineEdit_47->setObjectName(QString::fromUtf8("lineEdit_47"));
        lineEdit_47->setGeometry(QRect(280, 370, 113, 20));
        lineEdit_47->setReadOnly(true);
        lineEdit_37 = new QLineEdit(PersonPanel);
        lineEdit_37->setObjectName(QString::fromUtf8("lineEdit_37"));
        lineEdit_37->setGeometry(QRect(20, 310, 113, 20));
        lineEdit_37->setReadOnly(true);
        lineEdit_15 = new QLineEdit(PersonPanel);
        lineEdit_15->setObjectName(QString::fromUtf8("lineEdit_15"));
        lineEdit_15->setGeometry(QRect(280, 130, 113, 20));
        lineEdit_15->setReadOnly(true);
        lineEdit_2 = new QLineEdit(PersonPanel);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(150, 40, 113, 20));
        lineEdit_2->setReadOnly(true);
        lineEdit_10 = new QLineEdit(PersonPanel);
        lineEdit_10->setObjectName(QString::fromUtf8("lineEdit_10"));
        lineEdit_10->setGeometry(QRect(150, 100, 113, 20));
        lineEdit_10->setReadOnly(true);
        label_5 = new QLabel(PersonPanel);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(530, 0, 221, 391));
        label_5->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        label_6 = new QLabel(PersonPanel);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 390, 651, 101));
        label_6->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));

        retranslateUi(PersonPanel);

        QMetaObject::connectSlotsByName(PersonPanel);
    } // setupUi

    void retranslateUi(QWidget *PersonPanel)
    {
        PersonPanel->setWindowTitle(QCoreApplication::translate("PersonPanel", "Form", nullptr));
        label_4->setText(QCoreApplication::translate("PersonPanel", "\331\202\333\214\331\205\330\252 \330\247\330\252\331\210\331\205\330\250\333\214\331\204", nullptr));
        label_3->setText(QCoreApplication::translate("PersonPanel", "\330\263\330\247\331\204 \330\252\331\210\331\204\333\214\330\257 \330\247\330\252\331\210\331\205\330\250\333\214\331\204", nullptr));
        label_2->setText(QCoreApplication::translate("PersonPanel", "\330\261\331\206\332\257 \330\247\330\252\331\210\331\205\330\250\333\214\331\204", nullptr));
        label->setText(QCoreApplication::translate("PersonPanel", "\331\206\330\247\331\205 \330\247\330\252\331\210\331\205\330\250\333\214\331\204", nullptr));
        pushButton->setText(QCoreApplication::translate("PersonPanel", "\331\206\331\205\330\247\333\214\330\264 \330\247\330\267\331\204\330\247\330\271\330\247\330\252", nullptr));
        label_5->setText(QCoreApplication::translate("PersonPanel", "<html><head/><body><p align=\"center\"><span style=\" font-size:18pt; color:#ffffff;\"> \330\247\330\252\331\210\331\205\330\250\333\214\331\204 \330\250\330\261\330\254\332\257\330\247\331\206\333\214</span></p><p align=\"center\"><span style=\" font-size:18pt; color:#ffffff;\">Auto Borjegani</span></p></body></html>", nullptr));
        label_6->setText(QCoreApplication::translate("PersonPanel", "<html><head/><body><p align=\"right\">\330\263\331\204\330\247\331\205 \330\271\330\261\330\266 \331\205\333\214 \332\251\331\206\331\205 \330\256\330\257\331\205\330\252 \330\264\331\205\330\247 \330\250\330\247\330\262 \330\257\333\214\330\257 \332\251\331\206\331\206\330\257\332\257\330\247\331\206 \331\205\330\255\330\252\330\261\331\205</p><p align=\"right\">\330\247\333\214\331\206 \330\265\331\201\330\255\331\207 \330\257\331\210\330\247\330\262\330\257\331\207 \330\247\330\252\331\210\331\205\330\250\333\214\331\204 \330\247\330\262 \331\206\331\205\330\247\333\214\330\264\332\257\330\247\331\207 \330\250\330\261\330\254\332\257\330\247\331\206\333\214 \330\261\330\247 \330\250\330\261\330\247\333\214 \330\264\331\205\330\247 \330\271\330\262\333\214\330\262\330\247\331\206 \331\206\331\205\330\247\333\214\330\264 \331\205\333\214 \330\257\331\207\330\257</p><p align=\"right\">\330\247\332\257\330\261 \330\261\330\250\330\247\330\267 \331\206\333\214\330\263\330\252\333\214\330\257 \330\261\331\210\333"
                        "\214 \330\257\332\251\331\205\331\207 \333\214 \331\206\331\205\330\247\333\214\330\264 \330\247\330\267\331\204\330\247\330\271\330\247\330\252 \332\251\331\204\333\214\332\251 \332\251\331\206\333\214\330\257</p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PersonPanel: public Ui_PersonPanel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PERSONPANEL_H
