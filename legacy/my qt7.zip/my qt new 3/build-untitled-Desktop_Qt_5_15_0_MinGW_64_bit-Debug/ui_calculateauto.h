/********************************************************************************
** Form generated from reading UI file 'calculateauto.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALCULATEAUTO_H
#define UI_CALCULATEAUTO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CalculateAuto
{
public:
    QLineEdit *lineEdit;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QPushButton *pushButton_14;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QPushButton *pushButton_17;

    void setupUi(QWidget *CalculateAuto)
    {
        if (CalculateAuto->objectName().isEmpty())
            CalculateAuto->setObjectName(QString::fromUtf8("CalculateAuto"));
        CalculateAuto->resize(320, 371);
        CalculateAuto->setMinimumSize(QSize(320, 371));
        CalculateAuto->setMaximumSize(QSize(320, 371));
        CalculateAuto->setStyleSheet(QString::fromUtf8("background-color: qconicalgradient(cx:0.5, cy:0.5, angle:0, stop:0 rgba(35, 40, 3, 255), stop:0.16 rgba(136, 106, 22, 255), stop:0.225 rgba(166, 140, 41, 255), stop:0.285 rgba(204, 181, 74, 255), stop:0.345 rgba(235, 219, 102, 255), stop:0.415 rgba(245, 236, 112, 255), stop:0.52 rgba(209, 190, 76, 255), stop:0.57 rgba(187, 156, 51, 255), stop:0.635 rgba(168, 142, 42, 255), stop:0.695 rgba(202, 174, 68, 255), stop:0.75 rgba(218, 202, 86, 255), stop:0.815 rgba(208, 187, 73, 255), stop:0.88 rgba(187, 156, 51, 255), stop:0.935 rgba(137, 108, 26, 255), stop:1 rgba(35, 40, 3, 255));"));
        lineEdit = new QLineEdit(CalculateAuto);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(30, 20, 261, 41));
        lineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton = new QPushButton(CalculateAuto);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(30, 70, 51, 41));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"background-color: rgb(255, 255, 255);"));
        pushButton_2 = new QPushButton(CalculateAuto);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(100, 70, 51, 41));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_3 = new QPushButton(CalculateAuto);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(170, 70, 51, 41));
        pushButton_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_4 = new QPushButton(CalculateAuto);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(240, 70, 51, 41));
        pushButton_4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_5 = new QPushButton(CalculateAuto);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(170, 130, 51, 41));
        pushButton_5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_6 = new QPushButton(CalculateAuto);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(240, 130, 51, 41));
        pushButton_6->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_7 = new QPushButton(CalculateAuto);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(100, 130, 51, 41));
        pushButton_7->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_8 = new QPushButton(CalculateAuto);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(30, 130, 51, 41));
        pushButton_8->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_9 = new QPushButton(CalculateAuto);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setGeometry(QRect(170, 190, 51, 41));
        pushButton_9->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_10 = new QPushButton(CalculateAuto);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setGeometry(QRect(240, 190, 51, 41));
        pushButton_10->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_11 = new QPushButton(CalculateAuto);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));
        pushButton_11->setGeometry(QRect(100, 190, 51, 41));
        pushButton_11->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_12 = new QPushButton(CalculateAuto);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));
        pushButton_12->setGeometry(QRect(30, 190, 51, 41));
        pushButton_12->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_13 = new QPushButton(CalculateAuto);
        pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));
        pushButton_13->setGeometry(QRect(170, 250, 51, 41));
        pushButton_13->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_14 = new QPushButton(CalculateAuto);
        pushButton_14->setObjectName(QString::fromUtf8("pushButton_14"));
        pushButton_14->setGeometry(QRect(240, 250, 51, 41));
        pushButton_14->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_15 = new QPushButton(CalculateAuto);
        pushButton_15->setObjectName(QString::fromUtf8("pushButton_15"));
        pushButton_15->setGeometry(QRect(100, 250, 51, 41));
        pushButton_15->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_16 = new QPushButton(CalculateAuto);
        pushButton_16->setObjectName(QString::fromUtf8("pushButton_16"));
        pushButton_16->setGeometry(QRect(30, 250, 51, 41));
        pushButton_16->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        pushButton_17 = new QPushButton(CalculateAuto);
        pushButton_17->setObjectName(QString::fromUtf8("pushButton_17"));
        pushButton_17->setGeometry(QRect(30, 310, 261, 41));
        pushButton_17->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        retranslateUi(CalculateAuto);

        QMetaObject::connectSlotsByName(CalculateAuto);
    } // setupUi

    void retranslateUi(QWidget *CalculateAuto)
    {
        CalculateAuto->setWindowTitle(QCoreApplication::translate("CalculateAuto", "Form", nullptr));
        pushButton->setText(QCoreApplication::translate("CalculateAuto", "1", nullptr));
        pushButton_2->setText(QCoreApplication::translate("CalculateAuto", "2", nullptr));
        pushButton_3->setText(QCoreApplication::translate("CalculateAuto", "3", nullptr));
        pushButton_4->setText(QCoreApplication::translate("CalculateAuto", "+", nullptr));
        pushButton_5->setText(QCoreApplication::translate("CalculateAuto", "6", nullptr));
        pushButton_6->setText(QCoreApplication::translate("CalculateAuto", "-", nullptr));
        pushButton_7->setText(QCoreApplication::translate("CalculateAuto", "5", nullptr));
        pushButton_8->setText(QCoreApplication::translate("CalculateAuto", "4", nullptr));
        pushButton_9->setText(QCoreApplication::translate("CalculateAuto", "9", nullptr));
        pushButton_10->setText(QCoreApplication::translate("CalculateAuto", "\303\227", nullptr));
        pushButton_11->setText(QCoreApplication::translate("CalculateAuto", "8", nullptr));
        pushButton_12->setText(QCoreApplication::translate("CalculateAuto", "7", nullptr));
        pushButton_13->setText(QCoreApplication::translate("CalculateAuto", "=", nullptr));
        pushButton_14->setText(QCoreApplication::translate("CalculateAuto", "\303\267", nullptr));
        pushButton_15->setText(QCoreApplication::translate("CalculateAuto", "0", nullptr));
        pushButton_16->setText(QCoreApplication::translate("CalculateAuto", ".", nullptr));
        pushButton_17->setText(QCoreApplication::translate("CalculateAuto", "delete", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CalculateAuto: public Ui_CalculateAuto {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CALCULATEAUTO_H
