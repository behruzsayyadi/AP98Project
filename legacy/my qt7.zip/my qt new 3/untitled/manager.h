#ifndef MANAGER_H
#define MANAGER_H
#include"human.h"
#include <QMainWindow>
#include <QObject>
#include <QWidget>

class Manager:public Human
{
private:
    QString kode_meli;
    QString shomare_shenas;
    QString Address;
    QString Shoghl;
    QString telephon;
    QString mobile;
    QString birthday;
    QString username;
    QString password;
public:
    Manager();
    Manager(QString name,QString family,QString kodemeli,QString shomare,QString addres,QString shoghl,QString telephon,QString mobile,QString birthday,QString username,QString password);
};


#endif // MANAGER_H
