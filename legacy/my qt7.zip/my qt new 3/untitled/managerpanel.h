#ifndef MANAGERPANEL_H
#define MANAGERPANEL_H

#include <QWidget>

namespace Ui {
class ManagerPanel;
}

class ManagerPanel : public QWidget
{
    Q_OBJECT

public:
    explicit ManagerPanel(QWidget *parent = nullptr);
    ~ManagerPanel();

private slots:
    void on_pushButton_clicked();

private:
    Ui::ManagerPanel *ui;
};

#endif // MANAGERPANEL_H
