#include "radio5.h"
#include "ui_radio5.h"
#include"sabtchek.h"
#include<QFile>
#include<QTextStream>
#include<QString>
#include<QMessageBox>
#include<checkinfo.h>
#include<customer.h>
#include<seller.h>
#include"savari.h"
#include"vanetcar.h"
#include"shasiboland.h"
#include"dodar.h"
#include"korook.h"

Radio5::Radio5(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Radio5)
{
    ui->setupUi(this);
}

Radio5::~Radio5()
{
    delete ui;
}

void Radio5::on_pushButton_2_clicked()
{
    if(ui->radioButton_2->isChecked()==true){
        sabtchek*s=new sabtchek;
        s->setWindowTitle("ثبت اطلاعات چک");
        s->show();
    }
}

void Radio5::on_pushButton_clicked()
{


////////////////////////////////خریدار
se.setname(ui->lineEdit_21->text());
se.setfamily(ui->lineEdit_8->text());
se.setmobile(ui->lineEdit_9->text());
se.setkodemeli(ui->label_19->text());
se.sethomareshenas(ui->lineEdit_10->text());
se.settelephon(ui->lineEdit_13->text());
se.setbirhtday(ui->lineEdit_15->text());
se.setaddress(ui->lineEdit_27->text());
////////////////////////////////////خریدار


//////////////////////////////////////فروشنده
se.setname(ui->lineEdit_32->text());
se.setfamily(ui->lineEdit_25->text());
se.setmobile(ui->lineEdit_29->text());
se.setkodemeli(ui->label_22->text());
se.sethomareshenas(ui->lineEdit_30->text());
se.settelephon(ui->lineEdit_24->text());
se.setbirhtday(ui->lineEdit_31->text());
se.setaddress(ui->lineEdit_28->text());
/////////////////////////////////////////فروشنده



/////////////////////////////////////////////////اتومبیل
QString value=ui->comboBox_2->currentText();
if(value=="سواری"){

    s.setname(ui->lineEdit_20->text());
    s.setbrand(ui->lineEdit_18->text());
    s.setrang(ui->lineEdit_17->text());
    s.setInrang(ui->lineEdit_3->text());
    s.setsanad(ui->lineEdit_4->text());
    s.setshasi(ui->lineEdit_12->text());
    s.setgheymat(ui->lineEdit_23->text());
    s.setsal(ui->lineEdit_2->text());

}
    else if(value=="شاسی"){

    sh.setname(ui->lineEdit_20->text());
    sh.setbrand(ui->lineEdit_18->text());
    sh.setrang(ui->lineEdit_17->text());
    sh.setInrang(ui->lineEdit_3->text());
    sh.setsanad(ui->lineEdit_4->text());
    sh.setshasi(ui->lineEdit_12->text());
    sh.setgheymat(ui->lineEdit_23->text());
    sh.setsal(ui->lineEdit_2->text());

    }

    else if(value=="وانت"){

    v.setname(ui->lineEdit_20->text());
    v.setbrand(ui->lineEdit_18->text());
    v.setrang(ui->lineEdit_17->text());
    v.setInrang(ui->lineEdit_3->text());
    v.setsanad(ui->lineEdit_4->text());
    v.setshasi(ui->lineEdit_12->text());
    v.setgheymat(ui->lineEdit_23->text());
    v.setsal(ui->lineEdit_2->text());

    }
    else if(value=="کروک"){

    k.setname(ui->lineEdit_20->text());
    k.setbrand(ui->lineEdit_18->text());
    k.setrang(ui->lineEdit_17->text());
    k.setInrang(ui->lineEdit_3->text());
    k.setsanad(ui->lineEdit_4->text());
    k.setshasi(ui->lineEdit_12->text());
    k.setgheymat(ui->lineEdit_23->text());
    k.setsal(ui->lineEdit_2->text());

    }

    else if(value=="دودر"){

    d.setname(ui->lineEdit_20->text());
    d.setbrand(ui->lineEdit_18->text());
    d.setrang(ui->lineEdit_17->text());
    d.setInrang(ui->lineEdit_3->text());
    d.setsanad(ui->lineEdit_4->text());
    d.setshasi(ui->lineEdit_12->text());
    d.setgheymat(ui->lineEdit_23->text());
    d.setsal(ui->lineEdit_2->text());

    }




///////////////////////////////////////////////////////////////اتومبیل


//////////////////////////////////////////////////////////////چک های دریافتی
int number=ui->lineEdit_33->text().toUInt();

QFile myfile("C:\\Users\\user\\Desktop\\allFile\\newChek.txt");
if(!myfile.open(QFile::ReadOnly|QFile::Text)){

}

else{
QTextStream in(&myfile);
for(int i=0;i<number;i++){
    ch[i].setmoney(in.readLine());
    ch[i].setdate(in.readLine());
    ch[i].setshenase(in.readLine());

}

}

myfile.close();
/////////////////////////////////////////////////////////////////////چک های دریافتی
QMessageBox msg;
msg.setWindowTitle("ثبت");
msg.setText("با موفقیت ثبت شد");
msg.exec();

}
