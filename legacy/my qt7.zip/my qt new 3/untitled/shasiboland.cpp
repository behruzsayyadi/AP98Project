#include "shasiboland.h"

ShasiBoland::ShasiBoland()
{

}
double ShasiBoland:: getpoorsant(double allmoney){
    return (0.02*allmoney);
}
