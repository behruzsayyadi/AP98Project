#include "seller.h"

Seller::Seller()
{

}
void Seller:: setname(QString name){
    this->name=name;
}
void Seller:: setfamily(QString family){
    this->family=family;
}
void Seller:: setkodemeli(QString kodemeli){
    this->kode_meli=kodemeli;
}
void Seller:: sethomareshenas(QString shomare){
    this->shomare_shenas=shomare;
}
void Seller:: setaddress(QString address){
    this->Address=address;
}
void Seller:: settelephon(QString telephon){
    this->telephon=telephon;
}
void Seller:: setmobile(QString mobile){
    this->mobile=mobile;
}
void Seller:: setbirhtday(QString birhday){
    this->birthday=birhday;
}
QString Seller:: getname(){
    return name;
}
QString Seller:: getfamily(){
    return family;
}
QString Seller:: getkodemeli(){
    return kode_meli;
}
QString Seller:: gethomareshenas(){
    return shomare_shenas;
}
QString Seller:: getaddress(){
    return Address;
}
QString Seller:: gettelephon(){
return telephon;
}
QString Seller:: getmobile(){
    return mobile;
}
QString Seller:: getbirhtday(){
    return birthday;
}
