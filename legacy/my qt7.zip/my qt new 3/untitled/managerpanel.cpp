#include "managerpanel.h"
#include "ui_managerpanel.h"
#include"optionform.h"
#include"qapplication.h"
#include<QFile>
#include<QString>
#include<QTextStream>
#include<QMessageBox>

ManagerPanel::ManagerPanel(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ManagerPanel)
{
    ui->setupUi(this);
}

ManagerPanel::~ManagerPanel()
{
    delete ui;
}

void ManagerPanel::on_pushButton_clicked()
{
    QString username="";
    QString password="";
    QFile myfile("C:\\Users\\user\\Desktop\\allFile\\managerinfo.txt");
    if(!myfile.open(QFile::ReadOnly|QFile::Text)){


    }
    else{
        QTextStream in(&myfile);
        username=in.readLine();
        password=in.readLine();

    }
    if( ui->lineEdit_3->text()==username && ui->lineEdit_4->text()==password){


    ui->lineEdit_3->setText("");
    ui->lineEdit_4->setText("");
    optionform *option=new optionform;
    option->setWindowTitle("Mr.Borjegani");
    option->show();
    }

}
