#include "personpanel.h"
#include "ui_personpanel.h"
#include<QString>
#include<QFile>
#include<QTextStream>

PersonPanel::PersonPanel(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PersonPanel)
{
    ui->setupUi(this);
}

PersonPanel::~PersonPanel()
{
    delete ui;
}

void PersonPanel::on_pushButton_clicked()
{
    QFile myfile("C:\\Users\\user\\Desktop\\allFile\\12CarInAuto.txt");
    if(!myfile.open(QFile::ReadOnly|QFile::Text)){

    }

    else{
        QTextStream in(&myfile);
        ui->lineEdit->setText(in.readLine());
        ui->lineEdit_2->setText(in.readLine());
        ui->lineEdit_3->setText(in.readLine());
        ui->lineEdit_4->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_5->setText(in.readLine());
        ui->lineEdit_6->setText(in.readLine());
        ui->lineEdit_7->setText(in.readLine());
        ui->lineEdit_8->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_9->setText(in.readLine());
        ui->lineEdit_10->setText(in.readLine());
        ui->lineEdit_11->setText(in.readLine());
        ui->lineEdit_12->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_13->setText(in.readLine());
        ui->lineEdit_14->setText(in.readLine());
        ui->lineEdit_15->setText(in.readLine());
        ui->lineEdit_16->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_17->setText(in.readLine());
        ui->lineEdit_18->setText(in.readLine());
        ui->lineEdit_19->setText(in.readLine());
        ui->lineEdit_20->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_21->setText(in.readLine());
        ui->lineEdit_22->setText(in.readLine());
        ui->lineEdit_23->setText(in.readLine());
        ui->lineEdit_24->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_25->setText(in.readLine());
        ui->lineEdit_26->setText(in.readLine());
        ui->lineEdit_27->setText(in.readLine());
        ui->lineEdit_28->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_29->setText(in.readLine());
        ui->lineEdit_30->setText(in.readLine());
        ui->lineEdit_31->setText(in.readLine());
        ui->lineEdit_32->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_33->setText(in.readLine());
        ui->lineEdit_34->setText(in.readLine());
        ui->lineEdit_35->setText(in.readLine());
        ui->lineEdit_36->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_37->setText(in.readLine());
        ui->lineEdit_38->setText(in.readLine());
        ui->lineEdit_39->setText(in.readLine());
        ui->lineEdit_40->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_41->setText(in.readLine());
        ui->lineEdit_42->setText(in.readLine());
        ui->lineEdit_43->setText(in.readLine());
        ui->lineEdit_44->setText(in.readLine());
        ////////////////////////////////////////
        ui->lineEdit_45->setText(in.readLine());
        ui->lineEdit_46->setText(in.readLine());
        ui->lineEdit_47->setText(in.readLine());
        ui->lineEdit_48->setText(in.readLine());




    }
    myfile.close();


}
