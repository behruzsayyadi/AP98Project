#include "manager.h"

Manager::Manager()
{

}

Manager::Manager(QString name,QString family,QString kodemeli,QString shomare,QString addres,QString shoghl,QString telephon,QString mobile,QString birthday,QString username,QString password)
    :Human(name,family){
    this->username=username;
    this->password=password;
    this->kode_meli=kodemeli;
    this->shomare_shenas=shomare;
    this->Address=addres;
    this->Shoghl=shoghl;
    this->telephon=telephon;
    this->mobile=mobile;
    this->birthday=birthday;
}
