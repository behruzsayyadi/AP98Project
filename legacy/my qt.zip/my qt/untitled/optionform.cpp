#include "optionform.h"
#include "ui_optionform.h"

optionform::optionform(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::optionform)
{
    ui->setupUi(this);
}

optionform::~optionform()
{
    delete ui;
}
