#ifndef OPTIONFORM_H
#define OPTIONFORM_H

#include <QWidget>

namespace Ui {
class optionform;
}

class optionform : public QWidget
{
    Q_OBJECT

public:
    explicit optionform(QWidget *parent = nullptr);
    ~optionform();

private:
    Ui::optionform *ui;
};

#endif // OPTIONFORM_H
