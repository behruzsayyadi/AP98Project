/********************************************************************************
** Form generated from reading UI file 'optionform.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OPTIONFORM_H
#define UI_OPTIONFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_optionform
{
public:
    QRadioButton *radioButton;
    QRadioButton *radioButton_3;
    QRadioButton *radioButton_4;
    QRadioButton *radioButton_5;
    QRadioButton *radioButton_6;
    QRadioButton *radioButton_7;
    QRadioButton *radioButton_8;
    QRadioButton *radioButton_10;
    QRadioButton *radioButton_11;
    QRadioButton *radioButton_12;
    QRadioButton *radioButton_9;
    QRadioButton *radioButton_14;
    QPushButton *pushButton;
    QLabel *label;

    void setupUi(QWidget *optionform)
    {
        if (optionform->objectName().isEmpty())
            optionform->setObjectName(QString::fromUtf8("optionform"));
        optionform->resize(662, 494);
        optionform->setMinimumSize(QSize(662, 494));
        optionform->setMaximumSize(QSize(662, 494));
        radioButton = new QRadioButton(optionform);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));
        radioButton->setGeometry(QRect(420, 400, 151, 17));
        radioButton_3 = new QRadioButton(optionform);
        radioButton_3->setObjectName(QString::fromUtf8("radioButton_3"));
        radioButton_3->setGeometry(QRect(60, 210, 161, 17));
        radioButton_4 = new QRadioButton(optionform);
        radioButton_4->setObjectName(QString::fromUtf8("radioButton_4"));
        radioButton_4->setGeometry(QRect(250, 120, 111, 17));
        radioButton_5 = new QRadioButton(optionform);
        radioButton_5->setObjectName(QString::fromUtf8("radioButton_5"));
        radioButton_5->setGeometry(QRect(60, 120, 171, 17));
        radioButton_6 = new QRadioButton(optionform);
        radioButton_6->setObjectName(QString::fromUtf8("radioButton_6"));
        radioButton_6->setGeometry(QRect(250, 310, 141, 17));
        radioButton_7 = new QRadioButton(optionform);
        radioButton_7->setObjectName(QString::fromUtf8("radioButton_7"));
        radioButton_7->setGeometry(QRect(60, 310, 91, 17));
        radioButton_8 = new QRadioButton(optionform);
        radioButton_8->setObjectName(QString::fromUtf8("radioButton_8"));
        radioButton_8->setGeometry(QRect(430, 120, 221, 17));
        radioButton_10 = new QRadioButton(optionform);
        radioButton_10->setObjectName(QString::fromUtf8("radioButton_10"));
        radioButton_10->setGeometry(QRect(250, 210, 91, 17));
        radioButton_11 = new QRadioButton(optionform);
        radioButton_11->setObjectName(QString::fromUtf8("radioButton_11"));
        radioButton_11->setGeometry(QRect(420, 310, 221, 17));
        radioButton_12 = new QRadioButton(optionform);
        radioButton_12->setObjectName(QString::fromUtf8("radioButton_12"));
        radioButton_12->setGeometry(QRect(430, 210, 121, 17));
        radioButton_9 = new QRadioButton(optionform);
        radioButton_9->setObjectName(QString::fromUtf8("radioButton_9"));
        radioButton_9->setGeometry(QRect(60, 400, 171, 17));
        radioButton_14 = new QRadioButton(optionform);
        radioButton_14->setObjectName(QString::fromUtf8("radioButton_14"));
        radioButton_14->setGeometry(QRect(250, 400, 151, 17));
        pushButton = new QPushButton(optionform);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(580, 460, 75, 23));
        label = new QLabel(optionform);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(210, 10, 241, 61));

        retranslateUi(optionform);

        QMetaObject::connectSlotsByName(optionform);
    } // setupUi

    void retranslateUi(QWidget *optionform)
    {
        optionform->setWindowTitle(QCoreApplication::translate("optionform", "Form", nullptr));
        radioButton->setText(QCoreApplication::translate("optionform", "\330\252\330\272\333\214\333\214\330\261 \330\261\331\205\330\262 \330\271\330\250\331\210\330\261 \331\210 \331\206\330\247\331\205 \332\251\330\247\330\261\330\250\330\261\333\214", nullptr));
        radioButton_3->setText(QCoreApplication::translate("optionform", "\330\254\330\263\330\252 \331\210 \330\254\331\210 \330\250\330\261 \330\247\330\263\330\247\330\263 \330\247\330\267\331\204\330\247\330\271\330\247\330\252", nullptr));
        radioButton_4->setText(QCoreApplication::translate("optionform", "\331\205\330\264\330\252\330\261\333\214 \331\207\330\247\333\214 \330\256\330\247\330\265", nullptr));
        radioButton_5->setText(QCoreApplication::translate("optionform", "\330\256\330\261\333\214\330\257 \331\210 \331\201\330\261\331\210\330\264 \330\247\330\252\331\210\331\205\330\250\333\214\331\204 ", nullptr));
        radioButton_6->setText(QCoreApplication::translate("optionform", "\330\257\330\261\330\247\331\205\330\257 \331\206\330\247\330\264\333\214 \330\247\330\262 \331\276\331\210\330\261\330\263\330\247\331\206\330\252", nullptr));
        radioButton_7->setText(QCoreApplication::translate("optionform", "\330\252\330\272\333\214\333\214\330\261 \330\261\331\205\330\262 \330\257\331\210\331\205", nullptr));
        radioButton_8->setText(QCoreApplication::translate("optionform", "\331\276\330\261 \330\257\330\261\330\247\331\205\330\257 \330\252\330\261\333\214\331\206 \331\210 \332\251\331\205 \330\257\330\261\330\247\331\205\330\257 \330\252\330\261\333\214\331\206 \331\205\330\247\331\207 \330\257\330\261 \330\247\333\214\331\206 \330\263\330\247\331\204", nullptr));
        radioButton_10->setText(QCoreApplication::translate("optionform", "\330\263\330\261\331\205\330\247\333\214\331\207 \332\257\330\260\330\247\330\261\330\247\331\206", nullptr));
        radioButton_11->setText(QCoreApplication::translate("optionform", "\330\252\330\271\330\257\330\247\330\257 \330\247\330\252\331\210\331\205\330\250\333\214\331\204 \331\207\330\247\333\214 \330\256\330\261\333\214\330\257\330\247\330\261\333\214 \331\210 \331\201\330\261\331\210\330\256\330\252\331\207 \330\264\330\257\331\207", nullptr));
        radioButton_12->setText(QCoreApplication::translate("optionform", "\330\252\331\202\331\210\333\214\331\205 \330\264\330\256\330\265\333\214 \330\264\331\205\330\247", nullptr));
        radioButton_9->setText(QCoreApplication::translate("optionform", "\331\205\330\247\330\264\333\214\331\206 \331\207\330\247\333\214 \331\205\331\210\330\254\331\210\330\257 \330\257\330\261 \331\206\331\205\330\247\333\214\330\264\332\257\330\247\331\207", nullptr));
        radioButton_14->setText(QCoreApplication::translate("optionform", "\331\206\331\205\330\247\333\214\330\264\332\257\330\247\331\207 \331\207\330\247\333\214 \330\262\333\214\330\261\331\205\330\254\331\205\331\210\330\271\331\207", nullptr));
        pushButton->setText(QCoreApplication::translate("optionform", "OK", nullptr));
        label->setText(QCoreApplication::translate("optionform", "<html><head/><body><p align=\"center\"><span style=\" font-size:14pt; font-weight:600; color:#00007f;\">\331\206\331\205\330\247\333\214\330\264\332\257\330\247\331\207 \330\247\330\252\331\210\331\205\330\250\333\214\331\204 \330\250\330\261\330\254\332\257\330\247\331\206\333\214</span></p><p align=\"center\"><span style=\" font-size:9pt;\">\331\204\330\267\331\201\330\247 \331\206\331\210\330\271 \331\201\330\271\330\247\331\204\333\214\330\252 \330\256\331\210\330\257 \330\261\330\247 \331\205\330\264\330\256\330\265 \332\251\331\206\333\214\330\257</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class optionform: public Ui_optionform {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OPTIONFORM_H
