/********************************************************************************
** Form generated from reading UI file 'personpanel.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PERSONPANEL_H
#define UI_PERSONPANEL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PersonPanel
{
public:

    void setupUi(QWidget *PersonPanel)
    {
        if (PersonPanel->objectName().isEmpty())
            PersonPanel->setObjectName(QString::fromUtf8("PersonPanel"));
        PersonPanel->resize(400, 300);

        retranslateUi(PersonPanel);

        QMetaObject::connectSlotsByName(PersonPanel);
    } // setupUi

    void retranslateUi(QWidget *PersonPanel)
    {
        PersonPanel->setWindowTitle(QCoreApplication::translate("PersonPanel", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PersonPanel: public Ui_PersonPanel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PERSONPANEL_H
