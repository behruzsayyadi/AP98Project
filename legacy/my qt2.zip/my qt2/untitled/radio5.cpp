#include "radio5.h"
#include "ui_radio5.h"

Radio5::Radio5(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Radio5)
{
    ui->setupUi(this);
}

Radio5::~Radio5()
{
    delete ui;
}
