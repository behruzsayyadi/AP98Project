#include "sabtchek.h"
#include "ui_sabtchek.h"
#include"checkinfo.h"

sabtchek::sabtchek(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::sabtchek)
{
    ui->setupUi(this);
}

sabtchek::~sabtchek()
{
    delete ui;
}

void sabtchek::on_pushButton_clicked()
{
    int i=0;
    Checkinfo ch[10];
    QString money;
    QString date;
    QString shenase;
    if(ui->lineEdit_34->text()!=""){
        money=ui->lineEdit_34->text();
        date=ui->lineEdit_36->text();
        shenase=ui->lineEdit_35->text();
        ch[i].setmoney(money);
        ch[i].setdate(date);
        ch[i].setshenase(shenase);
        i++;
    }
    if(ui->lineEdit_31->text()!=""){
        money=ui->lineEdit_31->text();
        date=ui->lineEdit_33->text();
        shenase=ui->lineEdit_32->text();
        ch[i].setmoney(money);
        ch[i].setdate(date);
        ch[i].setshenase(shenase);
        i++;
    }

    if(ui->lineEdit_28->text()!=""){
        money=ui->lineEdit_28->text();
        date=ui->lineEdit_30->text();
        shenase=ui->lineEdit_29->text();
        ch[i].setmoney(money);
        ch[i].setdate(date);
        ch[i].setshenase(shenase);
        i++;
    }
    if(ui->lineEdit->text()!=""){
        money=ui->lineEdit->text();
        date=ui->lineEdit_2->text();
        shenase=ui->lineEdit_3->text();
        ch[i].setmoney(money);
        ch[i].setdate(date);
        ch[i].setshenase(shenase);
        i++;
    }

    if(ui->lineEdit_4->text()!=""){
        money=ui->lineEdit_4->text();
        date=ui->lineEdit_6->text();
        shenase=ui->lineEdit_5->text();
        ch[i].setmoney(money);
        ch[i].setdate(date);
        ch[i].setshenase(shenase);
        i++;
    }

    if(ui->lineEdit_7->text()!=""){
        money=ui->lineEdit_7->text();
        date=ui->lineEdit_9->text();
        shenase=ui->lineEdit_8->text();
        ch[i].setmoney(money);
        ch[i].setdate(date);
        ch[i].setshenase(shenase);
        i++;
    }

    if(ui->lineEdit_10->text()!=""){
        money=ui->lineEdit_10->text();
        date=ui->lineEdit_12->text();
        shenase=ui->lineEdit_11->text();
        ch[i].setmoney(money);
        ch[i].setdate(date);
        ch[i].setshenase(shenase);
        i++;
    }

    if(ui->lineEdit_13->text()!=""){
        money=ui->lineEdit_13->text();
        date=ui->lineEdit_15->text();
        shenase=ui->lineEdit_14->text();
        ch[i].setmoney(money);
        ch[i].setdate(date);
        ch[i].setshenase(shenase);
        i++;
    }
    if(ui->lineEdit_16->text()!=""){
        money=ui->lineEdit_16->text();
        date=ui->lineEdit_18->text();
        shenase=ui->lineEdit_17->text();
        ch[i].setmoney(money);
        ch[i].setdate(date);
        ch[i].setshenase(shenase);
        i++;
    }
    if(ui->lineEdit_19->text()!=""){
        money=ui->lineEdit_19->text();
        date=ui->lineEdit_21->text();
        shenase=ui->lineEdit_20->text();
        ch[i].setmoney(money);
        ch[i].setdate(date);
        ch[i].setshenase(shenase);
        i++;
    }

}


