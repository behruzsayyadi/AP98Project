#ifndef CUSTOMER_H
#define CUSTOMER_H
#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include"human.h"

class Customer:public Human
{
private:
    QString kode_meli;
    QString shomare_shenas;
    QString Address;
    QString Shoghl;
    QString telephon;
    QString mobile;
    QString birthday;
public:
    Customer();
     Customer(QString name,QString family,QString kodemeli,QString shomare,QString addres,QString shoghl,QString telephon,QString mobile,QString birthday);
};



#endif // CUSTOMER_H
