#ifndef SELLER_H
#define SELLER_H
#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include"human.h"

class Seller:public Human
{
private:
    QString kode_meli;
    QString shomare_shenas;
    QString Address;
    QString Shoghl;
    QString telephon;
    QString mobile;
    QString birthday;
public:
    Seller();
    Seller(QString name,QString family,QString kodemeli,QString shomare,QString addres,QString shoghl,QString telephon,QString mobile,QString birthday);

};



#endif // SELLER_H
