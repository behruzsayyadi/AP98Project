#include "managerpanel.h"
#include "ui_managerpanel.h"
#include"optionform.h"
#include"qapplication.h"

ManagerPanel::ManagerPanel(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ManagerPanel)
{
    ui->setupUi(this);
}

ManagerPanel::~ManagerPanel()
{
    delete ui;
}

void ManagerPanel::on_pushButton_clicked()
{

    QString name="محمد عماد";
    QString family="برجگانی";
    QString username="9818393";
    QString password="1273462912";

    if(ui->lineEdit->text()==name && ui->lineEdit_2->text()==family && ui->lineEdit_3->text()==username && ui->lineEdit_4->text()==password){
    ui->lineEdit->setText("");
    ui->lineEdit_2->setText("");
    ui->lineEdit_3->setText("");
    ui->lineEdit_4->setText("");
    optionform *option=new optionform;
    option->setWindowTitle("Mr.Borjegani");
    option->show();
    }
}
