#include "seller.h"

Seller::Seller()
{

}
Seller::Seller(QString name,QString family,QString kodemeli,QString shomare,QString addres,QString shoghl,QString telephon,QString mobile,QString birthday)
    :Human(name,family){
    this->kode_meli=kodemeli;
    this->shomare_shenas=shomare;
    this->Address=addres;
    this->Shoghl=shoghl;
    this->telephon=telephon;
    this->mobile=mobile;
    this->birthday=birthday;
}
