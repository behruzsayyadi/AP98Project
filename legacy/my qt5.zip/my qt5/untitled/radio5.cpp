#include "radio5.h"
#include "ui_radio5.h"
#include"sabtchek.h"

Radio5::Radio5(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Radio5)
{
    ui->setupUi(this);
}

Radio5::~Radio5()
{
    delete ui;
}

void Radio5::on_pushButton_2_clicked()
{
    if(ui->radioButton_2->isChecked()==true){
        sabtchek*s=new sabtchek;
        s->setWindowTitle("ثبت اطلاعات چک");
        s->show();
    }
}
