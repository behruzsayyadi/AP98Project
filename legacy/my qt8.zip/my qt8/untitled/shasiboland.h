#ifndef SHASIBOLAND_H
#define SHASIBOLAND_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include"car.h"

class ShasiBoland:public Car
{
private:
    double poorsant;
public:
    ShasiBoland();
    double getpoorsant(double allmoney);
};

#endif // SHASIBOLAND_H
