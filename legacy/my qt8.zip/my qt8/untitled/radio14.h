#ifndef RADIO14_H
#define RADIO14_H

#include <QWidget>

namespace Ui {
class Radio14;
}

class Radio14 : public QWidget
{
    Q_OBJECT

public:
    explicit Radio14(QWidget *parent = nullptr);
    ~Radio14();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Radio14 *ui;
};

#endif // RADIO14_H
