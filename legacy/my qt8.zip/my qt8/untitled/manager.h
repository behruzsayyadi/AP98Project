#ifndef MANAGER_H
#define MANAGER_H
#include"human.h"
#include <QMainWindow>
#include <QObject>
#include <QWidget>

class Manager:public Human
{
public:
    QString kode_meli;
    QString shomare_shenas;
    QString Address;
    QString telephon;
    QString mobile;
    QString birthday;
    QString username;
    QString password;
public:
    void setname(QString name);
    void setfamily(QString family);
    QString getname();
    QString getfamily();
    Manager();
};


#endif // MANAGER_H
