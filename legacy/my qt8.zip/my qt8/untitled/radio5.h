#ifndef RADIO5_H
#define RADIO5_H

#include <QWidget>
#include<checkinfo.h>
#include<customer.h>
#include<seller.h>
#include"savari.h"
#include"vanetcar.h"
#include"shasiboland.h"
#include"dodar.h"
#include"korook.h"

namespace Ui {
class Radio5;
}

class Radio5 : public QWidget
{
    Q_OBJECT

public:
    Customer cu;
    Seller se;
    Savari s;
    ShasiBoland sh;
    VanetCar v;
    Korook k;
    Dodar d;
    Checkinfo ch[10];
    explicit Radio5(QWidget *parent = nullptr);
    ~Radio5();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::Radio5 *ui;
};

#endif // RADIO5_H
