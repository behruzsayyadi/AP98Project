#ifndef SAVARI_H
#define SAVARI_H
#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include"car.h"

class Savari:public Car
{
private:
    double poorsant;
public:
    Savari();
    double getpoorsant(double allmoney);
};

#endif // SAVARI_H
