#include "autogallery.h"

AutoGallery::AutoGallery()
{

}
void AutoGallery:: setnameauto(QString autoname){
    this->nameofauto=autoname;
}
void AutoGallery::setaddres(QString address){
    this->Addressofauto=address;
}
void AutoGallery::settelephon(QString telephon){
    this->Telephonofauto=telephon;
}
void AutoGallery::setmangername(QString managername){
    this->nameofmanager=managername;
}
QString AutoGallery::getnameauto(){
    return nameofauto;
}
QString AutoGallery::getaddress(){
    return Addressofauto;
}
QString AutoGallery::gettelephon(){
    return Telephonofauto;
}
QString AutoGallery::getmangername(){
    return nameofmanager;
}
