#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"QTime"
#include"qtimer.h"
#include"date.h"
#include"managerpanel.h"
#include"personpanel.h"
#include"qapplication.h"
#include"qapplication.h"
#include"calculateauto.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    setWindowTitle("نمایشگاه اتومبیل برجگانی");
    QTimer *timer=new QTimer(this);
    timer->setInterval(1000);
    timer->start();
    connect(timer,SIGNAL(timeout()),SLOT(clock()));


}
void MainWindow::clock(){
    QString timestr=QTime::currentTime().toString("hh:mm:ss");
    ui->label->setText(timestr);
}

MainWindow::~MainWindow()
{
    delete ui;
}




void MainWindow::on_pushButton_clicked()
{
    Date *ondate12=new Date;
    ondate12->setWindowTitle("تاریخ");
    ondate12->show();
}

void MainWindow::on_pushButton_2_clicked()
{
    ManagerPanel *manager=new ManagerPanel;
    PersonPanel *person=new PersonPanel;


    if(ui->radioButton->isChecked()==true){
        manager->setWindowTitle("Mr.Borjegani");
        manager->show();
    }

    else if(ui->radioButton_2->isChecked()==true){

        person->setWindowTitle("دوازده اتومبیل از نمایشگاه اتومبیل برجگانی");
        person->show();

    }
}

void MainWindow::on_pushButton_3_clicked()
{
    QApplication::exit();
}

void MainWindow::on_pushButton_4_clicked()
{
    CalculateAuto *c=new CalculateAuto;
    c->setWindowTitle("ماشین حساب");
    c->show();
}
