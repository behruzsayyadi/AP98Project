#include "human.h"

Human::Human()
{

}
Human::Human(QString name,QString family){
    this->name=name;
    this->family=family;
}
