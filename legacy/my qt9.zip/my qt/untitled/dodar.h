#ifndef DODAR_H
#define DODAR_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include"car.h"

class Dodar:public Car
{
private:
    double poorsant;
public:
    Dodar();
    double getpoorsant(double allmoney);
};

#endif // DODAR_H
