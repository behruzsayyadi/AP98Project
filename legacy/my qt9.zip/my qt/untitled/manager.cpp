#include "manager.h"

Manager::Manager()
{

}

void Manager::setname(QString name){
    this->name=name;
}
void Manager::setfamily(QString family){
    this->family=family;
}
QString Manager::getname(){
    return name;
}
QString Manager:: getfamily(){
    return family;
}

