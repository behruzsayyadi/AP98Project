#include "radio12.h"
#include "ui_radio12.h"
#include<QFile>
#include<QTextStream>
#include<QString>
#include<QMessageBox>

Radio12::Radio12(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Radio12)
{
    ui->setupUi(this);
    QFile myfile("C:\\Users\\user\\Desktop\\allFile\\managerinfo.txt");
    if(!myfile.open(QFile::ReadOnly|QFile::Text)){

    }
    else{
        QTextStream in(&myfile);
        m.setname(in.readLine());
        m.setfamily(in.readLine());
        m.username=in.readLine();
        m.password=in.readLine();
        m.kode_meli=in.readLine();
        m.shomare_shenas=in.readLine();
        m.telephon=in.readLine();
        m.mobile=in.readLine();
        m.birthday=in.readLine();
        ui->lineEdit->setText(m.getname()+m.getfamily());
        ui->lineEdit_2->setText(m.telephon);
        ui->lineEdit_3->setText(m.mobile);
        ui->lineEdit_4->setText(m.kode_meli);
        ui->lineEdit_5->setText(m.shomare_shenas);
        ui->lineEdit_70->setText(m.birthday);
    }
    myfile.close();
}

Radio12::~Radio12()
{
    delete ui;
}

void Radio12::on_pushButton_clicked()
{
    QFile myfile("C:\\Users\\user\\Desktop\\allFile\\rooydad.txt");
    if(!myfile.open(QFile::WriteOnly|QFile::Text)){

    }
    else{
    QTextStream out(&myfile);
    out<<ui->lineEdit_6->text()+"\n";
    out<<ui->lineEdit_7->text()+"\n";
    out<<ui->lineEdit_8->text()+"\n";
    out<<ui->lineEdit_9->text()+"\n";

    ////////////////////////////////////////
    out<<ui->lineEdit_10->text()+"\n";
    out<<ui->lineEdit_11->text()+"\n";
    out<<ui->lineEdit_12->text()+"\n";
    out<<ui->lineEdit_13->text()+"\n";


    out<<ui->lineEdit_14->text()+"\n";
    out<<ui->lineEdit_15->text()+"\n";
    out<<ui->lineEdit_16->text()+"\n";
    out<<ui->lineEdit_17->text()+"\n";

    ////////////////////////////////////////
    out<<ui->lineEdit_18->text()+"\n";
    out<<ui->lineEdit_19->text()+"\n";
    out<<ui->lineEdit_20->text()+"\n";
    out<<ui->lineEdit_21->text()+"\n";


    out<<ui->lineEdit_22->text()+"\n";
    out<<ui->lineEdit_23->text()+"\n";
    out<<ui->lineEdit_24->text()+"\n";
    out<<ui->lineEdit_25->text()+"\n";

    ////////////////////////////////////////
    out<<ui->lineEdit_26->text()+"\n";
    out<<ui->lineEdit_27->text()+"\n";
    out<<ui->lineEdit_28->text()+"\n";
    out<<ui->lineEdit_29->text()+"\n";

    out<<ui->lineEdit_30->text()+"\n";
    out<<ui->lineEdit_31->text()+"\n";
    out<<ui->lineEdit_32->text()+"\n";
    out<<ui->lineEdit_33->text()+"\n";

    ////////////////////////////////////////
    out<<ui->lineEdit_34->text()+"\n";
    out<<ui->lineEdit_35->text()+"\n";
    out<<ui->lineEdit_36->text()+"\n";
    out<<ui->lineEdit_37->text()+"\n";

    out<<ui->lineEdit_38->text()+"\n";
    out<<ui->lineEdit_39->text()+"\n";
    out<<ui->lineEdit_40->text()+"\n";
    out<<ui->lineEdit_41->text()+"\n";

    ////////////////////////////////////////
    out<<ui->lineEdit_42->text()+"\n";
    out<<ui->lineEdit_43->text()+"\n";
    out<<ui->lineEdit_44->text()+"\n";
    out<<ui->lineEdit_45->text()+"\n";

    ////////////////////////////////////////
    out<<ui->lineEdit_46->text()+"\n";
    out<<ui->lineEdit_47->text()+"\n";
    out<<ui->lineEdit_48->text()+"\n";
    out<<ui->lineEdit_49->text()+"\n";

    out<<ui->lineEdit_50->text()+"\n";
    out<<ui->lineEdit_51->text()+"\n";
    out<<ui->lineEdit_52->text()+"\n";
    out<<ui->lineEdit_53->text()+"\n";

    ////////////////////////////////////////
    out<<ui->lineEdit_54->text()+"\n";
    out<<ui->lineEdit_55->text()+"\n";
    out<<ui->lineEdit_56->text()+"\n";
    out<<ui->lineEdit_57->text()+"\n";



    ////////////////////////////////////////
    out<<ui->lineEdit_58->text()+"\n";
    out<<ui->lineEdit_59->text()+"\n";
    out<<ui->lineEdit_60->text()+"\n";
    out<<ui->lineEdit_61->text()+"\n";

    out<<ui->lineEdit_62->text()+"\n";
    out<<ui->lineEdit_63->text()+"\n";
    out<<ui->lineEdit_64->text()+"\n";
    out<<ui->lineEdit_65->text()+"\n";

    ////////////////////////////////////////
    out<<ui->lineEdit_66->text()+"\n";
    out<<ui->lineEdit_67->text()+"\n";
    out<<ui->lineEdit_68->text()+"\n";
    out<<ui->lineEdit_69->text()+"\n";


}
    myfile.flush();
    myfile.close();
    QMessageBox msg;
    msg.setWindowTitle("ثبت");
    msg.setText("با موفقیت ثبت شد");
    msg.exec();

}

void Radio12::on_pushButton_2_clicked()
{
    QFile myfile("C:\\Users\\user\\Desktop\\allFile\\rooydad.txt");
    if(!myfile.open(QFile::ReadOnly|QFile::Text)){

    }

    else{
        QTextStream in(&myfile);
        ui->lineEdit_6->setText(in.readLine());
        ui->lineEdit_7->setText(in.readLine());
        ui->lineEdit_8->setText(in.readLine());
        ui->lineEdit_9->setText(in.readLine());

        ////////////////////////////////////////
        ui->lineEdit_10->setText(in.readLine());
        ui->lineEdit_11->setText(in.readLine());
        ui->lineEdit_12->setText(in.readLine());
        ui->lineEdit_13->setText(in.readLine());

        ////////////////////////////////////////
        ui->lineEdit_14->setText(in.readLine());
        ui->lineEdit_15->setText(in.readLine());
        ui->lineEdit_16->setText(in.readLine());
        ui->lineEdit_17->setText(in.readLine());

        ////////////////////////////////////////
        ui->lineEdit_18->setText(in.readLine());
        ui->lineEdit_19->setText(in.readLine());
        ui->lineEdit_20->setText(in.readLine());
        ui->lineEdit_21->setText(in.readLine());

        ////////////////////////////////////////
        ui->lineEdit_22->setText(in.readLine());
        ui->lineEdit_23->setText(in.readLine());
        ui->lineEdit_24->setText(in.readLine());
        ui->lineEdit_25->setText(in.readLine());

        ////////////////////////////////////////
        ui->lineEdit_26->setText(in.readLine());
        ui->lineEdit_27->setText(in.readLine());
        ui->lineEdit_28->setText(in.readLine());
        ui->lineEdit_29->setText(in.readLine());

        ////////////////////////////////////////
        ui->lineEdit_30->setText(in.readLine());
        ui->lineEdit_31->setText(in.readLine());
        ui->lineEdit_32->setText(in.readLine());
        ui->lineEdit_33->setText(in.readLine());

        ////////////////////////////////////////
        ui->lineEdit_34->setText(in.readLine());
        ui->lineEdit_35->setText(in.readLine());
        ui->lineEdit_36->setText(in.readLine());
        ui->lineEdit_37->setText(in.readLine());

        ////////////////////////////////////////
        ui->lineEdit_38->setText(in.readLine());
        ui->lineEdit_39->setText(in.readLine());
        ui->lineEdit_40->setText(in.readLine());
        ui->lineEdit_41->setText(in.readLine());

        ////////////////////////////////////////
        ui->lineEdit_42->setText(in.readLine());
        ui->lineEdit_43->setText(in.readLine());
        ui->lineEdit_44->setText(in.readLine());
        ui->lineEdit_45->setText(in.readLine());








        ////////////////////////////////////////
        ui->lineEdit_46->setText(in.readLine());
        ui->lineEdit_47->setText(in.readLine());
        ui->lineEdit_48->setText(in.readLine());
        ui->lineEdit_49->setText(in.readLine());

        ////////////////////////////////////////
        ui->lineEdit_50->setText(in.readLine());
        ui->lineEdit_51->setText(in.readLine());
        ui->lineEdit_52->setText(in.readLine());
        ui->lineEdit_53->setText(in.readLine());

        ////////////////////////////////////////
        ui->lineEdit_54->setText(in.readLine());
        ui->lineEdit_55->setText(in.readLine());
        ui->lineEdit_56->setText(in.readLine());
        ui->lineEdit_57->setText(in.readLine());



        ////////////////////////////////////////
        ui->lineEdit_58->setText(in.readLine());
        ui->lineEdit_59->setText(in.readLine());
        ui->lineEdit_60->setText(in.readLine());
        ui->lineEdit_61->setText(in.readLine());

        ////////////////////////////////////////
        ui->lineEdit_62->setText(in.readLine());
        ui->lineEdit_63->setText(in.readLine());
        ui->lineEdit_64->setText(in.readLine());
        ui->lineEdit_65->setText(in.readLine());

        ////////////////////////////////////////
        ui->lineEdit_66->setText(in.readLine());
        ui->lineEdit_67->setText(in.readLine());
        ui->lineEdit_68->setText(in.readLine());
        ui->lineEdit_69->setText(in.readLine());






    }
    myfile.close();
}
