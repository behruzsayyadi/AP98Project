#ifndef CUSTOMER_H
#define CUSTOMER_H
#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include"human.h"

class Customer:public Human
{
private:
    QString kode_meli;
    QString shomare_shenas;
    QString Address;
    QString Shoghl;
    QString telephon;
    QString mobile;
    QString birthday;
public:
    Customer();
    void setname(QString name);
    void setfamily(QString family);
    void setkodemeli(QString kodemeli);
    void sethomareshenas(QString shomare);
    void setaddress(QString address);
    void settelephon(QString telephon);
    void setmobile(QString mobile);
    void setbirhtday(QString birhday);
    QString getname();
    QString getfamily();
    QString getkodemeli();
    QString gethomareshenas();
    QString getaddress();
    QString gettelephon();
    QString getmobile();
    QString getbirhtday();

};

#endif // CUSTOMER_H
