#include "savari.h"

Savari::Savari()
{

}

double Savari::getpoorsant(double allmoney){
    return (0.01*allmoney);
}
