#ifndef RADIO9_H
#define RADIO9_H

#include <QWidget>

namespace Ui {
class Radio9;
}

class Radio9 : public QWidget
{
    Q_OBJECT

public:
    explicit Radio9(QWidget *parent = nullptr);
    ~Radio9();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Radio9 *ui;
};

#endif // RADIO9_H
