#include "optionform.h"
#include "ui_optionform.h"
#include"radio5.h"
#include"radio.h"
#include"radio14.h"
#include<QFile>
#include<QString>
#include<QTextStream>
#include"radio9.h"
#include"radio10.h"
#include"radio4.h"
#include"radio12.h"
#include"radio3.h"
optionform::optionform(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::optionform)
{
    ui->setupUi(this);
}

optionform::~optionform()
{
    delete ui;
}

void optionform::on_pushButton_clicked()
{
    if(ui->radioButton_5->isChecked()==true){
        Radio5 *r=new Radio5;
        r->setWindowTitle("خرید و فروش اتومبیل");
        r->show();
    }
    /////////////////////////////////////////////
    else if(ui->radioButton->isChecked()==true){
     Radio *r=new Radio;
     r->setWindowTitle("تغیرات");
     r->show();
    }
    ///////////////////////////////////////////////
    else if(ui->radioButton_14->isChecked()==true){
        Radio14 *r=new Radio14;
        r->setWindowTitle("نمایشگاه ها ی همکار");
        r->show();



    }

/////////////////////////////////////////////////////////
else if(ui->radioButton_9->isChecked()==true){
     Radio9 *r=new Radio9;
     r->setWindowTitle("اتومبیل های موجود");
     r->show();

    }
    //////////////////////////////////////

    else if(ui->radioButton_10->isChecked()==true){
    Radio10 *r=new Radio10;
    r->setWindowTitle("سرمایه گذاران");
    r->show();

    }
    ////////////////////////////////////////////////////

    else if(ui->radioButton_4->isChecked()==true){
        Radio4 *r=new Radio4;
        r->setWindowTitle("مشتری های خاص");
        r->show();
    }


    //////////////////////////////////////////////////////
    else if(ui->radioButton_12->isChecked()==true){
        Radio12*r=new Radio12;
        r->setWindowTitle("رویداد های مهم");
        r->show();

    }
    ////////////////////////////////////////////////////////

    else if(ui->radioButton_3->isChecked()==true){
        Radio3 *r=new Radio3;
        r->setWindowTitle("جست و جوی اطلاعات");
        r->show();
    }
    /////////////////////////////////////////////////////////


}
