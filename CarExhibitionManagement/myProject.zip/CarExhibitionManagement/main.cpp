#include "MainWindow.h"

#include <QApplication>
#include <QDir>
#include <QDebug>
#include "Seller.h"
#include "Customer.h"
#include "Manager.h"
#include "CheckInfo.h"
#include  "Car.h"

int main(int argc, char *argv[])
{
    QApplication af(argc, argv);

    if( !QDir("Documents").exists() )
        QDir().mkdir("Documents");
    /*
    Checkinfo mychk("800000000","Melli","Talaghani",QDate(2021,5,13),"221-3332-554-12");
    mychk.addCheck();
    Checkinfo mychk2("500000000","Melli","Talaghani",QDate(2020,5,14),"221-3332-553-17");
    mychk2.addCheck();
    Checkinfo mychk4("800000000","Melli","Talaghani",QDate(2024,5,13),"221-3332-554-12");
    mychk4.addCheck();
    Checkinfo mychk3("800000000","Melli","Talaghani",QDate(2022,5,13),"221-3332-554-12");
    mychk3.addCheck();
    */

    /*
    QJsonArray a;
    a.append(3);
    a.append(2);
    a.append(4);
    a.append(1);
    a.replace(0,a[1].toInt());
    qDebug() << a;
    */
    QJsonArray a = loadChecks_jsonArray() ;
 //   b = checks_jsonArray_sort_by_date(a);
    qDebug() << checks_jsonArray_sort_by_date(a);
    MainWindow w;
    w.show();
    return af.exec();
}
